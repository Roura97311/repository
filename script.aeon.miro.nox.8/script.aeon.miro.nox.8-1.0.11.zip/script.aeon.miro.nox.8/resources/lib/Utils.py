#!/usr/bin/python
# coding: utf-8
#from __future__ import unicode_literals
import xbmcplugin, xbmcgui, xbmc, xbmcaddon, xbmcvfs
import os,sys,io,shutil
from . import youturl
import datetime

import _strptime
import time
import unicodedata
import urllib.request, urllib.error, urllib.parse, urllib.request, urllib.parse, urllib.error

import json
import sqlite3
import operator
import locale
import hashlib
import base64
import xml.etree.ElementTree as ET
    

    

ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])
WINDOW = xbmcgui.Window(10000)
SETTING = ADDON.getSetting
KODILANGUAGE = xbmc.getInfoLabel( "System.Language" )
KODILANGCODE = xbmc.getLanguage(xbmc.ISO_639_1).lower()
TMDBApiKey="67158e2af1624020e34fd893c881b019"
ListePays={"?":"Inconnu","AF":"Afghanistan","AL":"Albania","DZ":"Algeria","AS":"American Samoa","AD":"Andorra","AO":"Angola","AI":"Anguilla","AQ":"Antarctica","AG":"Antigua and Barbuda","AR":"Argentina","AM":"Armenia","AW":"Aruba","AU":"Australia","AT":"Austria","AZ":"Azerbaijan","BS":"Bahamas","BH":"Bahrain","BD":"Bangladesh","BB":"Barbados","BY":"Belarus",
"BE":"Belgium","BZ":"Belize","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","BO":"Bolivia, Plurinational State of","BA":"Bosnia and Herzegovina","BW":"Botswana","BV":"Bouvet Island","BR":"Brazil","IO":"British Indian Ocean Territory","BN":"Brunei Darussalam","BG":"Bulgaria","BF":"Burkina Faso","BI":"Burundi","KH":"Cambodia","CM":"Cameroon","CA":"Canada","CV":"Cape Verde","KY":"Cayman Islands","CF":"Central African Republic","TD":"Chad",
"CL":"Chile","CN":"China","CX":"Christmas Island","CC":"Cocos (Keeling) Islands","CO":"Colombia","KM":"Comoros","CG":"Congo","CD":"Congo, the Democratic Republic of the","CK":"Cook Islands","CR":"Costa Rica","CI":"Cote d'Ivoire","HR":"Croatia","CU":"Cuba","CY":"Cyprus","CZ":"Czech Republic","DK":"Denmark","DJ":"Djibouti","DM":"Dominica","DO":"Dominican Republic","EC":"Ecuador","EG":"Egypt","SV":"El Salvador","GQ":"Equatorial Guinea","ER":"Eritrea","EE":"Estonia","ET":"Ethiopia","FK":"Falkland Islands (Malvinas)","FO":"Faroe Islands","FJ":"Fiji","FI":"Finland","FR":"France",
"GF":"French Guiana","PF":"French Polynesia","TF":"French Southern Territories","GA":"Gabon","GM":"Gambia","GE":"Georgia","DE":"Germany","GH":"Ghana","GI":"Gibraltar","GR":"Greece","GL":"Greenland","GD":"Grenada","GP":"Guadeloupe","GU":"Guam","GT":"Guatemala","GG":"Guernsey","GN":"Guinea","GW":"Guinea-Bissau","GY":"Guyana","HT":"Haiti","HM":"Heard Island and McDonald Islands","VA":"Holy See (Vatican City State)","HN":"Honduras","HK":"Hong Kong","HU":"Hungary","IS":"Iceland","IN":"India","ID":"Indonesia","IR":"Iran, Islamic Republic of","IQ":"Iraq","IE":"Ireland","IM":"Isle of Man",
"IL":"Israel","IT":"Italy","JM":"Jamaica","JP":"Japan","JE":"Jersey","JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KI":"Kiribati","KP":"Korea, Democratic People's Republic of","KR":"Korea, Republic of","KW":"Kuwait","KG":"Kyrgyzstan","LA":"Lao People's Democratic Republic","LV":"Latvia","LB":"Lebanon","LS":"Lesotho","LR":"Liberia","LY":"Libyan Arab Jamahiriya","LI":"Liechtenstein","LT":"Lithuania","LU":"Luxembourg","MO":"Macao","MK":"Macedonia, the former Yugoslav Republic of","MG":"Madagascar","MW":"Malawi","MY":"Malaysia","MV":"Maldives","ML":"Mali","MT":"Malta","MH":"Marshall Islands","MQ":"Martinique","MR":"Mauritania","MU":"Mauritius","YT":"Mayotte","MX":"Mexico","FM":"Micronesia, Federated States of","MD":"Moldova, Republic of","MC":"Monaco",
"MN":"Mongolia","ME":"Montenegro","MS":"Montserrat","MA":"Morocco","MZ":"Mozambique","MM":"Myanmar","NA":"Namibia","NR":"Nauru","NP":"Nepal","NL":"Netherlands","AN":"Netherlands Antilles","NC":"New Caledonia","NZ":"New Zealand","NI":"Nicaragua","NE":"Niger","NG":"Nigeria","NU":"Niue","NF":"Norfolk Island","MP":"Northern Mariana Islands","NO":"Norway","OM":"Oman","PK":"Pakistan","PW":"Palau","PS":"Palestinian Territory, Occupied","PA":"Panama","PG":"Papua New Guinea","PY":"Paraguay","PE":"Peru","PH":"Philippines","PN":"Pitcairn","PL":"Poland","PT":"Portugal","PR":"Puerto Rico",
"QA":"Qatar","RE":"Reunion","RO":"Romania","RU":"Russian Federation","RW":"Rwanda","BL":"Saint Barthelemy","SH":"Saint Helena, Ascension and Tristan da Cunha","KN":"Saint Kitts and Nevis","LC":"Saint Lucia","MF":"Saint Martin (French part)","PM":"Saint Pierre and Miquelon","VC":"Saint Vincent and the Grenadines","WS":"Samoa","SM":"San Marino","ST":"Sao Tome and Principe","SA":"Saudi Arabia","SN":"Senegal","RS":"Serbia","SC":"Seychelles","SL":"Sierra Leone","SG":"Singapore","SK":"Slovakia","SI":"Slovenia","SB":"Solomon Islands","SO":"Somalia","ZA":"South Africa","GS":"South Georgia and the South Sandwich Islands","ES":"Spain","LK":"Sri Lanka","SD":"Sudan","SR":"Suriname","SJ":"Svalbard and Jan Mayen","SZ":"Swaziland","SE":"Sweden","CH":"Switzerland","SY":"Syrian Arab Republic","TW":"Taiwan, Province of China",
"TJ":"Tajikistan","TZ":"Tanzania, United Republic of","TH":"Thailand","TL":"Timor-Leste","TG":"Togo","TK":"Tokelau","TO":"Tonga","TT":"Trinidad and Tobago","TN":"Tunisia","TR":"Turkey","TM":"Turkmenistan","TC":"Turks and Caicos Islands","TV":"Tuvalu","UG":"Uganda","UA":"Ukraine","AE":"United Arab Emirates","GB":"United Kingdom","US":"United States of America","UM":"United States Minor Outlying Islands","UY":"Uruguay","UZ":"Uzbekistan","VU":"Vanuatu","VE":"Venezuela, Bolivarian Republic of","VN":"Viet Nam","VG":"Virgin Islands, British","VI":"Virgin Islands, U.S.","WF":"Wallis and Futuna","EH":"Western Sahara","YE":"Yemen","ZM":"Zambia","ZW":"Zimbabwe","":"?","00":"?"
}
__skin_string__ = xbmc.getLocalizedString
sys.path.append(xbmcvfs.translatePath(os.path.join(ADDON_PATH, 'resources', 'lib')))


def logMsg(msg, level = 0): #ca c'est pour debugger. ca ecrit le message MSG dans Kodi.log
    if WINDOW.getProperty("IconMixTools.enableDebugLog") == "true" or level == 0:
        
        if "exception" in msg.lower() or "error" in msg.lower():
            xbmc.log("IconMixToolsMiroNox addon --> " + msg, level=xbmc.LOGERROR)
            #print_exc()
        else:
            xbmc.log("IconMixToolsMiroNox addon --> " + msg, level=xbmc.LOGINFO)





# --------------------------------------------ACTEURS/REALISATEURS----------------------------------------------
        
def getCasting(Castingtypex=None,ItemId=None,Statique=None,MissingId=None):
  allCast = []
  item = {}
  Casting = []
  Castingtype=""
  imageacteur="" 
  ListeActeur=[]
 
  
  NonVide=xbmc.getCondVisibility("Skin.HasSetting(HideMovieTvCastEmpty)")
  #videodb://movies/actors/1132/   1132=id acteur pour retrouver ses films
  
  if  (len(sys.argv)>1 and sys.argv[1]) or Statique:
      if Castingtypex and ( ItemId or MissingId ):   
         #if Castingtypex=="episode":            Castingtypex="tvshow"
    
         Castingtype="VideoLibrary.Get%sDetails" %(Castingtypex)
         if ItemId and not MissingId:
          json_result = getJSON(Castingtype, '{ "%sid":%d,"properties": [ "cast","uniqueid"]}' %(Castingtypex,int(ItemId)))
          
         else :
            if not 'movie' in Castingtypex:
              Typex="tv"
            else:
              Typex="movie"
            QueryURL="%s%s/%s/credits?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,Typex,MissingId,TMDBApiKey,KODILANGCODE) 
            json_result = requestUrlJson(QueryURL)

         #movie, tvshow
         if json_result:
            if json_result.get('uniqueid'):
              try:
                TMDBID=json_result.get('uniqueid').get('tmdb')
              except:
                TMDBID=None
              logMsg('UNIQUEID = %s' %TMDBID)
            allCast = json_result.get("cast")  
         if allCast:
           for Test in allCast:
             name=Test.get("name")
             if Castingtypex=="episode":
              if int(Test.get("order"))==0 and Test.get("role")=="": #directeur
                name=None
             if name :
                 if ItemId and not MissingId:
                   imageacteur=Test.get("thumbnail")
                 else:
                   if Test.get("profile_path"):
                    imageacteur="http://image.tmdb.org/t/p/original"+str(Test.get("profile_path"))
                   else:
                    imageacteur=None
                 if not imageacteur and not NonVide:
                    imageacteur="defaultactor.png"
                 #else :
                 if imageacteur:
                     if not MissingId:
                       imageacteur=urllib.parse.unquote(imageacteur.replace("image://","")[:-1])
                     else:
                       imageacteur=urllib.parse.unquote(imageacteur.replace("image://",""))
                     label2x=Test.get("role")
                     if not label2x:
                       label2x=Test.get("character")
                     ItemListe = xbmcgui.ListItem(label=name,label2=label2x)
                     ItemListe.setArt({'icon':imageacteur})
                     ItemListe.setProperty("DbType","acteurs")
                     if not Statique:
                         ListeActeur.append(["",ItemListe,True])
                     else:
                         ListeActeur.append(ItemListe)
                         
  if not Statique:
     xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeActeur)
     xbmcplugin.endOfDirectory(int(sys.argv[1]))
  else:
     return ListeActeur 
 

     
def ActeurFilmsTvKODI(ActeurType=None,Acteur=None,Statique=None):
  Donnees = []
  item = {}
  Casting = []
  RechercheType=""
  VideoPoster="" 
  ListeVideos=[]
  #checkitem=["art","cast","country","dateadded","director","episode","episodeid","fanart","file","firstaired","genre","imdbnumber","lastplayed","mpaa","originaltitle","playcount","plot","plotoutline","productioncode","rating","ratings","resume","runtime","season","seasonid","set","setid","showlink","showtitle","sorttitle","specialsortepisode","specialsortseason","streamdetails","studio","tag","tagline","thumbnail","title","top250","trailer","tvshowid","uniqueid","userrating","votes","writer","year"]
  #checkitemok=[]
  
  #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"filter":{"actor":"marion cotillard"},"properties":["thumbnail","year","file"]},"id":"1"}
  #videodb://movies/actors/1132/   1132=id acteur pour retrouver ses films
  if  (len(sys.argv)>1 and sys.argv[1]) or Statique:
      if Acteur: 
         if ActeurType and ActeurType=="director":
            Ok=""
         else: ActeurType="actor"
        
         Acteur=Remove_Separator(Acteur)
         #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"filter":{"field":"director","operator":"contains","value":"ridley"},"properties":["thumbnail","year","file"]},"id":"1"}       
         json_result = getJSON("VideoLibrary.GetMovies", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["art", "cast", "country", "dateadded", "director", "fanart", "file", "genre", "imdbnumber", "lastplayed", "mpaa", "originaltitle", "playcount", "plot", "plotoutline", "rating", "ratings", "resume", "runtime", "set", "setid", "showlink", "sorttitle", "streamdetails", "studio", "tag", "tagline", "thumbnail", "title", "top250", "trailer", "uniqueid", "userrating", "votes", "writer", "year"]}' %(ActeurType,Acteur))
         json_result2 = getJSON("VideoLibrary.GetTvShows", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["art", "cast", "dateadded", "episode", "fanart", "file", "genre", "imdbnumber", "lastplayed", "mpaa", "originaltitle", "playcount", "plot", "rating", "ratings", "runtime", "season", "sorttitle", "studio", "tag", "thumbnail", "title", "uniqueid", "userrating", "votes", "year"]}' %(ActeurType,Acteur))
         
         #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":30,"properties":["cast"],"filter":{"actor":"CynthiaAddai-Robinson"}},"id":"1"}
         #pour obtenir tous les episodes comprenant l'acteur
         
         if len(json_result)>0:
          Donnees=json_result
          logMsg("Donnees 1")
         if len(json_result2)>0:
          Donnees = [*Donnees, *json_result2]
          #Donnees=Donnees+json_result2
          logMsg("Donnees 2")        
         #movie, tvshow
                  
         if Donnees:
           
           for Item in Donnees:
             try:
                Titre=Item.get("label")
             except:
              Titre=None
             if Titre:
                 ItemListe = xbmcgui.ListItem(label=Titre)
                 ItemListe.setArt({'icon':Item.get("art").get("poster")})
                 ItemListe.setProperty("poster",Item.get("art").get("poster")) 
                 Casting = Item.get("cast")
                 logMsg("Casting : %s" %Casting)
                 if Casting:
                    for ItemCast in  Casting:
                         if ItemCast.get("name")==Acteur:
                              ItemListe.setLabel2(ItemCast.get("role"))
                              ItemListe.setProperty('role',ItemCast.get("role"))
                              break  
                 
                 IdVideo=Item.get("movieid")
                 TypeVideo="movie"
                 if not IdVideo: 
                    IdVideo=Item.get("tvshowid")
                    TypeVideo="tvshow"
                 ItemListe.setArt( Item.get("art"))
                 Fanart=Item.get("art").get("fanart")
                 if Fanart:
                     ItemListe.setProperty("fanart",Fanart)
                 else:
                     ItemListe.setProperty("fanart","")
                 
                 ItemListe.setProperty('DBID', str(IdVideo))
                 ItemListe.setProperty('dbtype',TypeVideo)
                 ItemListe.setProperty('IMDBNumber', str(Item.get("imdbnumber")))
                 ItemListe.setProperty('Rating',str(int(Item.get("rating")))) 
                 UserRating=Item.get("userrating")
                 if UserRating:
                     if int(UserRating)>0:
                       ItemListe.setProperty('UserRating',str(int(Item.get("userrating"))))
                     else:
                       ItemListe.setProperty('UserRating','')
                 
                 #pistes audios tele
                 try:
                   Audio=Item.get("streamdetails").get("audio")
                 except:
                   Audio=None
                 i=1
                 if Audio:               
                       for AudioElement in Audio:
                            ItemListe.setProperty('AudioLanguage.%d' %(i), AudioElement.get("language").lower())
                            ItemListe.setProperty('AudioChannels.%d' %(i), str(AudioElement.get("channels")).lower())
                            ItemListe.setProperty('AudioCodec.%d' %(i), AudioElement.get("codec").lower()) 
                            ItemListe.addStreamInfo('audio',AudioElement)                   
                            i=i+1
            
                  #pistes vid�os 
                 try:
                   Video=Item.get("streamdetails").get("video")
                 except:
                   Video=None
                 i=0
                 Codec=""
                 if Video:
                    #{"aspect":2.3975000381469726563,"codec":"h264","duration":5584,"height":800,"language":"eng","stereomode":"","width":1918}
                    for VideoItem in Video:
                       ItemListe.setProperty('VideoCodec', VideoItem.get("codec")) 
                       ItemListe.addStreamInfo('video',VideoItem)
                       
                  #sous-titres  
                 try:   
                   Subtitles=Item.get("streamdetails").get("subtitle")
                 except:
                   Subtitles=None
                 i=1
                  
                 if Subtitles:
                       for SubtitleElement in Subtitles:
                            ItemListe.setProperty('SubtitleLanguage.%d' %(i), SubtitleElement.get("language"))  
                            ItemListe.addStreamInfo('subtitle',SubtitleElement)                   
                            i=i+1
                 Genre=Item.get("genre")               
                 if Genre:
                  listegenre=""
                  for IGenre in Genre:
                    #listegenre.append(tmdbgenre.get(str(IGenre )))
                    if listegenre!="":
                      listegenre=listegenre+','
                    listegenre=listegenre+IGenre
                  Item["genre"]=listegenre  
                  
                 InfoLabels=GetListItemInfoLabelsJson(Item)
                 if InfoLabels:
                   InfoLabels["mediatype"]= TypeVideo
                   ItemListe.setInfo("video", InfoLabels)
                   ItemListe.setPath(Item.get("file"))
                   if not Statique:
                       ListeVideos.append([Item.get("file"),ItemListe,False])
                   else:
                       #ListeVideos.append(ItemListe)
                       try:
                            Annee=Item.get("year")
                       except:
                            Annee="0"
                       if not Annee or Annee=="":
                        Annee="0" 
                       ListeVideos.append([int(Annee),ItemListe])
                 
  
  if not Statique:               
     xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeVideos)       
     xbmcplugin.endOfDirectory(int(sys.argv[1])) 
  else:
     ListeItemFinal=[]
     LL=[]
     logMsg("tri debut")               
     LL=sorted(ListeVideos, key=lambda x:x[0],reverse=True)
     logMsg("Tri par Annee")
     #tri par ann�e
     cpt=0
     while cpt<len(LL):
             ListeItemFinal.append(LL[cpt][1])
             cpt=cpt+1
           
     return ListeItemFinal

def to_unicode(texte):
  return texte
def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD',  try_decode(input_str))
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)])
    
def Remove_Separator(Chaine=None):
  if Chaine:
    Chaine=Chaine.split("/")[0].rstrip()
    Chaine=Chaine.split("&")[0].rstrip()
    Chaine=Chaine.split(",")[0].rstrip()
    Chaine=Chaine.replace('"','')
    Chaine=Chaine.replace("'",'')
  return Chaine
  
def checksavepath(chemin=None):
  if chemin:
    try:
      xbmcvfs.mkdirs(ADDON_DATA_PATH+"/%s" %(chemin))
    except:
      i=0
def GetTMDBGenres():
  globalgenre={}
  checksavepath(ADDON_DATA_PATH)
  savepath=ADDON_DATA_PATH+"/tmdbgenres"
  if xbmcvfs.exists(savepath):
    with open(savepath,encoding='utf-8') as data_file:
      try:
        globalgenre = json.load(data_file)
      except:
        globalgenre=""
       
  if len(globalgenre)<1:  
    QueryURL="https://api.themoviedb.org/3/genre/movie/list?api_key=67158e2af1624020e34fd893c881b019&language=%s" %KODILANGCODE
    json_data = requestUrlJson(QueryURL)
    if json_data:
      for item in json_data.get("genres"):
        globalgenre[str(item.get("id"))]=item.get("name")   
    
    QueryURL="https://api.themoviedb.org/3/genre/tv/list?api_key=67158e2af1624020e34fd893c881b019&language=%s" %KODILANGCODE
    json_data = requestUrlJson(QueryURL)
    if json_data:
      for item in json_data.get("genres"):
        globalgenre[str(item.get("id"))]=item.get("name")
    
    
    
    with io.open(savepath, 'w', encoding='utf8',errors='ignore') as outfile: 
        str_ = json.dumps(globalgenre,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
        outfile.write(to_unicode(str_)) 
    logMsg("TMDBGENRES OK")
  return globalgenre


def ActeurFilmsTvTMDB(ActeurType=None,Acteur=None,Statique=None):
  allInfo = []
  item = {}
  Casting = []
  Castingtype=""
  imageacteur="" 
  ListeRoles=[]
  ListeId=[]
  ActeurId={}
  ActeurCache={}
  json_data=None
  logMsg("ActeurFilmsTvTMDB (%s)" %Acteur)
  
  ActeurSave=1
  ActeurCache["nom"]=None
  ActeurCache["id"]=None
  if ActeurType and ActeurType=="director":
            ActeurType='realisateurs'
            ActeurCache["crew"]=[]
  else: ActeurType="acteurs"
  if ActeurType and Acteur!="None": 
     
     if Acteur:
        tmdbgenre=GetTMDBGenres()
        Acteur=Remove_Separator(Acteur)
        ActeurCache["cast"]=[] 
        checksavepath(ActeurType)
        check=remove_accents(Acteur)
        savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,check.replace(" ", "_"))
        
        #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,str(unidecode(Acteur)).replace(" ", "_"))
        if savepath and xbmcvfs.exists(savepath):
          with open(savepath,encoding='utf-8') as data_file:
                  json_data = json.load(data_file)
                  ActeurSave=0
                  data_file.close()
                  if not json_data.get("cast") or not json_data.get("checkcastV7") or (ActeurType=="realisateurs" and not json_data.get("crew")):
                    ActeurSave=1
                  #if not json_data.get("biographie"):  
                  #  json_data=json_data+GetActeurInfo(Acteur)
                  #  ActeurSave=1
                  if json_data:                      
                      ActeurCache["biographie"]=json_data.get("biographie")
                      ActeurCache["naissance"]=json_data.get("naissance")                  
                      ActeurCache["deces"]=json_data.get("deces")                                                 
                      ActeurCache["lieunaissance"]=json_data.get("lieunaissance")
                      ActeurCache["nom"]=json_data.get("nom")
                      ActeurCache["nomreel"]=json_data.get("nomreel")
                      ActeurCache["id"]=json_data.get("id")
          ActeurId=json_data.get("id")
        else:
          ActeurId=GetActeurId(Acteur) 
        
        if savepath and ActeurId.get("tmdb") and (not xbmcvfs.exists(savepath) or ActeurSave>0):
            QueryURL = "%sperson/%s/combined_credits?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey,KODILANGCODE) 
            logMsg("QueryTMDB (%s)" %QueryURL)
            json_data = requestUrlJson(QueryURL)
            ActeurCache["checkcastV7"]="ok"
         
        if json_data: 
                  Donnees=None
                  if ActeurType!='realisateurs':
                    Donnees=json_data.get("cast")
                  if ActeurType=='realisateurs':
                    Donnees=json_data.get("crew")
                    
                  if Donnees:
                                     
                    for item in Donnees:                       
                       TypeVideo=str(item.get("media_type"))
                       name=""                     
                       if TypeVideo=="movie": name=item.get("title")
                       else : name=item.get("name")
                       if name:
                         
                         IdFix=item.get("id")
                         Ajout=1
                         if IdFix:
                            if not IdFix in ListeId:
                               ListeId.append(IdFix)                                                     
                            else:
                               Ajout=0
                         if Ajout>0:                                                                                
                              Poster=item.get("poster_path")
                              if not Poster:
                                Poster=item.get("backdrop_path")
                              if not Poster:                                  
                                 if TypeVideo=="movie": Poster="defaultmovietitle.png"
                                 else: Poster="defaulttvshowtitle.png"
                              else: Poster="http://image.tmdb.org/t/p/original"+str(Poster)
                              if TypeVideo=="tv":
                                TypeVideo="tvshow"
                              
                              if ActeurType!='realisateurs':
                                ActeurCache["cast"].append(item)
                                Role=item.get("character")
                              if ActeurType=='realisateurs':
                                ActeurCache["crew"].append(item)
                                Role=item.get("job")
                              if not Role:
                                 Role="?"
                              logMsg("acteur* : %s / role:%s" %(name,Role))
                              ItemListe = xbmcgui.ListItem(label=name,label2=Role)
                              ItemListe.setArt({'icon':Poster})
                              ItemListe.setProperty("poster",Poster)
                              ItemListe.setProperty("role",Role)
                              ItemListe.setArt({"poster":Poster})
                              Fanart=item.get("backdrop_path")
                              if Fanart:
                                 Fanart="http://image.tmdb.org/t/p/original"+Fanart
                                 ItemListe.setProperty("fanart",Fanart)
                              else:
                                 Fanart=""
                                 
                              try:
                                Annee=item.get("release_date").split("-")[0]
                              except:
                                Annee=None
                              if not Annee:
                                 try: 
                                   Annee=item.get("first_air_date").split("-")[0]
                                 except:
                                   Annee="0"
                              if not Annee or Annee=="":
                                Annee="0"
                             
                              
                              try:
                                Rating=float(item.get("vote_average"))
                              except:
                                Rating=None
                              logMsg("TmdbRating : %s" %Rating)
                              try:
                                  ItemPays=item.get("origin_country")
                              except:
                                  ItemPays=None
                              if ItemPays:
                                Pays=[]
                                for paysitem in ItemPays:
                                  if len(paysitem)<4:
                                    Pays.append(ListePays.get(paysitem.upper()).encode("utf8"))
                                  else:
                                    Pays.append(paysitem.upper().encode("utf8"))
                                
                              else:
                                  Pays=None
                              Genre=item.get("genre_ids")                              
                              listegenre=""
                              if Genre:
                                for IGenre in Genre:
                                  #listegenre.append(tmdbgenre.get(str(IGenre )))
                                  if listegenre!="":
                                    listegenre=listegenre+','
                                  listegenre=listegenre+tmdbgenre.get(str(IGenre ))
                              
                              ItemListe.setProperty("TMDBNumber",str(IdFix))
                              #ItemListe.setProperty('Rating',Rating) 
                              ItemListe.setProperty("dbtype",TypeVideo.replace("id",""))
                              ItemListe.setArt({'poster':Poster,'fanart':Fanart,'landscape':Fanart,'icon':Poster})
                              ItemListe.setInfo("video", {"title": name,"genre": listegenre,"mediatype": TypeVideo.replace("id",""),"rating":Rating,"year": Annee,"originaltitle": item.get("original_title"),"trailer":item.get("id"),"plot":item.get("overview"),"country":Pays})        
                              
                              if not Statique:
                                 ListeRoles.append(["",ItemListe,True])
                              else :
                                 #ListeRoles.append(ItemListe)
                                 ListeRoles.append([int(Annee),ItemListe])
                
                            
                  if savepath and ActeurSave>0:
                        #erreur=DirStru(savepath)
                        #ActeurCache["cast"]=json_data.get("cast") 
                        #ActeurCache["crew"]=json_data.get("crew")  
                        
                        if not ActeurCache["nom"]: ActeurCache["nom"]=str(Acteur)                         
                        if not ActeurCache["id"]: ActeurCache["id"]=ActeurId    
                        try:                    
                          with io.open(savepath, 'w', encoding='utf8',errors='ignore') as outfile: 
                            str_ = json.dumps(ActeurCache,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
                            outfile.write(to_unicode(str_)) 
                        except:
                          logMsg("Erreur ActeurFilmsTvTMDB io.open (%s)" %(savepath) ) 
                          
                  if not Statique:     
                      xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeRoles)
                                      
  if not Statique:
      xbmcplugin.endOfDirectory(int(sys.argv[1])) 
  else:
     ListeItemFinal=[]
     LL=[]          
     #LL=sorted(ListeRoles,reverse=True)
     LL=sorted(ListeRoles, key=lambda x:x[0],reverse=True)
     #tri par ann�e
     cpt=0
     while cpt<len(LL):
             ListeItemFinal.append(LL[cpt][1])
             cpt=cpt+1
           
     return ListeItemFinal     

def getTMDBMovieDetails(IDVIDEO=None,DBTYPE=None,KodiDB=None):
  infomovie={}
  if DBTYPE and IDVIDEO and not KodiDB:
    if 'movie' in DBTYPE.lower():
      DBTYPE='movie'
    else:
      DBTYPE='tv'
    QueryURL="%s%s/%s?api_key=%s&language=%s&include_adult=true" %(BaseUrlTMDB,DBTYPE,IDVIDEO,TMDBApiKey,KODILANGCODE)
    json_data = requestUrlJson(QueryURL)
    if json_data:
      infomovie["duree"]=json_data.get('runtime')
      #https://api.themoviedb.org/3/movie/293660/credits?api_key=67158e2af1624020e34fd893c881b019&language=en-US
      QueryURL="%s%s/%s/credits?api_key=%s&language=%s&include_adult=true" %(BaseUrlTMDB,DBTYPE,IDVIDEO,TMDBApiKey,KODILANGCODE)
      json_data = requestUrlJson(QueryURL)
      if json_data:
        donnees=json_data.get("cast")
        Acteurs=[]
        if donnees:
          cpt=1 
          for item in donnees:
            nom=item.get("name")
            role=item.get("character")
            photo=item.get("profile_path")
            if photo:
              photo="http://image.tmdb.org/t/p/original"+photo
            Acteurs.append({'name':nom,'role':role,'thumbnail':photo,'order':cpt})
            cpt=cpt+1  
      data=getOneTrailer(ID=IDVIDEO,DbType=DBTYPE,SaisonID=None)
      if data:
        infomovie['Trailer']=data[0].get('url')      
      infomovie['Acteurs']=Acteurs
  else:
    Castingtype="VideoLibrary.Get%sDetails" %(DBTYPE)    
    json_result = getJSON(Castingtype, '{ "%sid":%d,"properties": [ "cast","uniqueid"]}' %(DBTYPE,int(IDVIDEO)))
    return json_result.get('cast')
  return infomovie
            
  
  

def getOneTrailer(ID=None,DbType=None,SaisonID=None):
     Donnees=[]
     ListeTrailer=[]
     #https://api.themoviedb.org/3/movie/$$IDFILM$$/videos?api_key=67158e2af1624020e34fd893c881b019&language=French      
     #https://api.themoviedb.org/3/tv/$$IDTV$$/videos?api_key=67158e2af1624020e34fd893c881b019&language=French  
     #https://api.themoviedb.org/3/search/tv?api_key=67158e2af1624020e34fd893c881b019&language=en-US&query=American%20Horror%20Story&page=1
     

     
     if ID:
        if DbType: 
          MediaQualite=720 #par defaut
          logMsg("getTrailer (%s)(%s)" %(DbType,ID))
          if DbType!="movie":
               QueryURL ="%stv/%s/videos?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey,KODILANGCODE)
          else:
               QueryURL ="%smovie/%s/videos?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey,KODILANGCODE)
          json_data = requestUrlJson(QueryURL) #en francais
          if json_data:
            Donnees=json_data.get("results")               
          if DbType!="movie":
               QueryURL ="%stv/%s/videos?api_key=%s&language=en&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey)
          else:
               QueryURL ="%smovie/%s/videos?api_key=%s&language=en&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey)
          #logMsg("getTrailer (%s)(%s)(%s)" %(DbType,ID,QueryURL))
          json_data = requestUrlJson(QueryURL) #en anglais
          if json_data:
            Donnees=Donnees+json_data.get("results") 
            #{"id":181808,"results":[{"id":"59dca043c3a368623e070253","iso_639_1":"fr","iso_3166_1":"FR","key":"_pkhEAC8YTU","name":"Bande Annonce VOST","site":"YouTube","size":1080,"type":"Trailer"}]}         
          
          if Donnees:
               cc=0
               for Item in Donnees:
                    #{"id":"56609361c3a36875e00047c2","iso_639_1":"en","iso_3166_1":"US","key":"ScY179qa5pM","name":"Season 5 (Hotel) Opening","site":"YouTube","size":1080,"type":"Opening Credits"}
                    Item["sizenull"]=""
                    try:               
                      ItemSize=int(Item.get("size"))
                    except:
                      ItemSize=720 #par d�faut
                    try:
                      TypeTrailer=Item.get("type").lower()
                    except:
                      TypeTrailer=""
                    try:
                      Site=Item.get("site").lower()
                    except:
                      Site=""  
                      
                    if SaisonID:
                      Nom=Item.get("name")
                      if Nom:
                        data=re.search(r"Season (.{1,3}) ", Nom)
                        if data:
                          try:
                            SaisonTMDB=int(data.group(1))
                          except:
                            SaisonTMDB=0
                          if SaisonTMDB!=int(SaisonID):
                            Site="rejet"
                    #logMsg("YT TypeTrailer (%s)(%s)(%s)(%s)(%s)" %(ID,TypeTrailer,Item.get("key"),Site,ItemSize),0)
                    #if Site=="youtube" and ItemSize>=MediaQualite and (TypeTrailer=="trailer" or not AnnonceUniquement):
                    if Site=="youtube" and ItemSize>=MediaQualite and TypeTrailer=="trailer":
                         Item["position"]=str(cc) 
                         Item["id"]='plugin://plugin.video.youtube/play/?video_id=%s' %(Item["key"])                         
                         Item["landscape"]="http://img.youtube.com/vi/%s/hqdefault.jpg" %(Item["key"])
                         urlyoutube=youturl.getyoutubeurl(Item["key"])
                         if urlyoutube:
                           Item["url"]=urlyoutube  
                         Item["key"]="YouTube"
                         
                         ListeTrailer.append(Item)
                         cc=cc+1
                         break
     logMsg("ListeTrailer : %s" %ListeTrailer)
     return ListeTrailer
       
def GetActeurId(Acteur):
    
  ActeurId={}
  if Acteur!="None":  
        #allocine pour les frenchies ;)
        #ActeurId["allocine"]=''
        #Acteur=try_decode(Acteur.split("(")[0])
        #ActeurId["allocine"]=Allocine_ChercheActeur(Acteur)
        
          #TMDB   
        try:
          check=Acteur.encode('utf8')
        except:
          check=Acteur 
        QueryURL = "%ssearch/person?api_key=%s&language=%s&query=%s&page=1&include_adult=true" % (BaseUrlTMDB,TMDBApiKey,KODILANGCODE,urllib.parse.quote(check))
        logMsg("getacteurid : QueryURL (%s)" %(QueryURL))
        json_data = requestUrlJson(QueryURL)              
        ActeurId["tmdb"]=None        
        if json_data:
            allInfo=json_data.get("results")            
            
            if allInfo:
              for item in allInfo:
                if not ActeurId["tmdb"]:
                   ActeurId["tmdb"]=str(item.get("id"))
                   logMsg("GetActeurId ActeurTMDBID (%s)" %(str(ActeurId["tmdb"])),0)
                break
  logMsg("retour GetActeurId")
  return ActeurId 

def GetActeurInfo(NomActeur,ActeurType="acteurs"):
  ActeurCache={}
  ActeurId={}
  Bio=None
  json_data={}
  SaveActeur=0
  
  if ActeurType and "director" in ActeurType:
            ActeurType='realisateurs'
  if ActeurType and "actor" in ActeurType:
            ActeurType='acteurs'
  if NomActeur and ActeurType:
    NomActeur=Remove_Separator(NomActeur)
    
    check=remove_accents(try_decode(NomActeur))
    #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,remove_accents(NomActeur.encode("utf8","ignore").decode("utf8","ignore").replace(" ", "_")))
    #NomActeur=NomActeur.encode("utf8","ignore").decode("utf8","ignore")
    checksavepath(ActeurType)
    try:
          savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,check.replace(" ", "_"))
    except:
      savepath=None
    
    if xbmcvfs.exists(savepath):
        with open(savepath,encoding='utf-8') as data_file:
                  try:
                    json_data = json.load(data_file)
                  except:
                    json_data=None
                  data_file.close() 
                  if json_data:
                      ActeurCache["cast"]=json_data.get("cast") 
                      ActeurId=json_data.get("id")
                      Bio='biographie' in json_data
                      if not json_data.get("v6"):
                        Bio=None
                       
                      #Bio=json_data.get("biographie")
                      
                  
   
    
    if not Bio or not ActeurId :
          if not ActeurId :            
            ActeurId=GetActeurId(NomActeur)
          if ActeurId:
            json_data=GetActeurInfoMaj(ActeurId,NomActeur)
            logMsg("BIOGRAPHIE : %s " %json_data.get("biographie"))
          else:
            return ActeurCache          
           
    if json_data : 
              ActeurCache["biographie"]=json_data.get("biographie")
              ActeurCache["naissance"]=json_data.get("naissance")                  
              ActeurCache["deces"]=json_data.get("deces")                                                 
              ActeurCache["lieunaissance"]=json_data.get("lieunaissance")
              ActeurCache["nom"]=try_decode(json_data.get("nom"))
              ActeurCache["nomreel"]=try_decode(json_data.get("nomreel"))
              ActeurCache["poster"]=json_data.get("poster")
              ActeurCache["id"]=ActeurId
              ActeurCache["v6"]="ok"
              if SETTING("cacheacteur")=="false" and savepath:
                  erreur=DirStru(savepath) 
                  try:           
                    with io.open(savepath, 'w+', encoding='utf8',errors='ignore') as outfile: 
                      str_ = json.dumps(ActeurCache,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
                      outfile.write(to_unicode(str_))
                  except:
                    logMsg("Erreur GetActeurInfo io.open (%s)" %(savepath) )
  return ActeurCache

def GetActeurInfoMaj(ActeurId,NomActeur):
  #http://www.imdb.com/xml/find?json=1&nr=1&nm=on&q=Cynthia%20Addai-Robinson
  json_data={}
  json_datatmdb={}
  ActeurCache={}
  if ActeurId:
    if NomActeur:
      ActeurCache["nom"]=NomActeur
    if KODILANGUAGE[0:4]=='Fren' and ActeurId.get("allocine"):
          if (ActeurId["allocine"]!='') :        
            #si pas de bio en francais  et language de Kodi est French 
            json_datax=Allocine_Acteur(ActeurId.get("allocine"))
            
            if json_datax:
              
              jsonacteurdata=json.loads(json_datax)             
              if jsonacteurdata and KODILANGUAGE[0:4]=='Fren':
                      jsonActeur=jsonacteurdata.get("person")
                      if jsonActeur:
                        json_data["name"]=NomActeur 
                        json_data["realName"]=jsonActeur.get("realName")
                        json_data["biography"]=jsonActeur.get("biography")
                        json_data["birthday"]=jsonActeur.get("birthDate")      
                        json_data["deathday"]=''                                                 
                        json_data["place_of_birth"]=jsonActeur.get("birthPlace")
                        try:
                          json_data["poster"]=jsonActeur.get("picture")["href"] 
                        except:
                          json_data["poster"]=None
                        #ActeurId='allo'+str(AllocineId)                     
            
    if ActeurId.get("tmdb"):
        if not json_data.get("biography"):           
          #on recherche sur tmdb dans la langue de KODI
            QueryURL = "%sperson/%s?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey,KODILANGCODE) 
            json_datatmdb = requestUrlJson(QueryURL) 
        try:
          biobio=json_data.get("biography")
        except:
          biobio=None
        try:
          biobio2=json_datatmdb.get("biography")
        except:
          biobio2=None
        
            
        if not json_data or (not biobio and not biobio2):   
              #pas de biographie dans la langue de KODI alors on cherche en Anglais......
              QueryURL = "%sperson/%s?api_key=%s&language=EN&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey) 
              json_datatmdb = requestUrlJson(QueryURL)
          
       
    if json_data or json_datatmdb: 
          if json_data and json_data.get("biography"):
             ActeurCache["biographie"]=json_data.get("biography")
          else:
             if not json_datatmdb:
              ActeurCache["biographie"]=""
             else:
              ActeurCache["biographie"]=json_datatmdb.get("biography")
             
          if json_data and json_data.get("birthday"):
             ActeurCache["naissance"]=json_data.get("birthday")
          else:
             if not json_datatmdb:
              ActeurCache["naissance"]=""
             else:
              ActeurCache["naissance"]=json_datatmdb.get("birthday")
             
          if json_data and json_data.get("deathday"):
             ActeurCache["deces"]=json_data.get("deathday")
          else:
             if not json_datatmdb:
              ActeurCache["deces"]=""
             else:
              ActeurCache["deces"]=json_datatmdb.get("deathday")
             
          if json_data and json_data.get("place_of_birth"):
             ActeurCache["lieunaissance"]=json_data.get("place_of_birth")
          else:
             if not json_datatmdb:
              ActeurCache["lieunaissance"]=""
             else:
              ActeurCache["lieunaissance"]=json_datatmdb.get("place_of_birth")
             
          if json_data and json_data.get("name"):
             ActeurCache["nom"]=json_data.get("name")
          else:
             if not json_datatmdb:
              ActeurCache["nom"]=""
             else:
              ActeurCache["nom"]=json_datatmdb.get("name")
             
          if json_data and json_data.get("realName"):
             ActeurCache["nomreel"]=json_data.get("realName")
          else:
             if not json_datatmdb:
              ActeurCache["nomreel"]=""
             else:
              ActeurCache["nomreel"]=json_datatmdb.get("realName")
          
          
          #"picture":{"name":"Photo Matthew Vaughn","path":"/pictures/15/01/15/17/40/151965.jpg","href":"http://fr.web.img2.acsta.net/pictures/15/01/15/17/40/151965.jpg"}
          
          
          if json_data and json_data.get("poster"):
             ActeurCache["poster"]=json_data.get("poster")
          else:
             if not json_datatmdb:
              ActeurCache["poster"]=""
             else:
              if json_datatmdb.get("profile_path"):
                ActeurCache["poster"]="http://image.tmdb.org/t/p/original"+json_datatmdb.get("profile_path")    
              
                 
          

                
  return ActeurCache  
    
def GetPhotoRealisateur(CheminType="",realisateur=None,HttpUniquement=None):
    allInfo = []
    realisateurId=""
    savepath=""   
    Poster=None  
    #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,str(unidecode(NomActeur)).replace(" ", "_"))
    
    if realisateur and len(realisateur)>4: 
          realisateur=Remove_Separator(realisateur)
          zig=try_decode(realisateur).replace('"','')
          check=remove_accents(zig.replace(" ", "_"))
          savepath=ADDON_DATA_PATH+"/%s/%s" %(CheminType,check)
          if xbmcvfs.exists(savepath+".jpg"):
              return(savepath+".jpg")
              
          if xbmcvfs.exists(savepath):
              with open(savepath,encoding='utf-8') as data_file:
                  try:
                    json_data = json.load(data_file)
                  except:
                    json_data=None
                  data_file.close() 
                  Poster=None
                  if json_data:
                      Poster=json_data.get("poster") 
                      if savepath:
                        return Poster
                      #Bio=json_data.get("biographie")
          
          if not Poster and savepath:  
             Poster="defaultactor.png" 
             Cache=GetActeurInfo(zig,CheminType)
             if Cache :
                Poster=Cache.get("poster")
                
                
                if (CheminType=="realisateurs" and SETTING("cacherealisateur")=="false") or (CheminType=="acteurs" and SETTING("cacheacteur")=="false"):
                   QueryURL=Poster
                   try:                      
                     erreur=DirStru(savepath+".jpg")
                     urllib.request.urlretrieve(QueryURL,savepath+".jpg")
                   except :
                     str_response=''
                     Poster="defaultactor.png"

    return(Poster if Poster else "defaultactor.png") 
#------------------------------------

# --------------------------------------------UTILITAIRES/PLUGIN----------------------------------------------
def Remove_Separator(Chaine=None):
  if Chaine:
    Chaine=Chaine.split("/")[0].rstrip()
    Chaine=Chaine.split("&")[0].rstrip()
    Chaine=Chaine.split(",")[0].rstrip()
    Chaine=Chaine.replace('"','')
    Chaine=Chaine.replace("'",'')
  return Chaine  

def GetListItemInfoLabelsJson(data=None):
    
  if data:
    Valeur={}
    
    Valeur["genre"]=data.get("genre")
    if data.get("country"):
      Country=[]
      if len(data.get("country"))>1:
        for xx in data.get("country"):
          Country.append(xx)
      else:
        Country=data.get("country")[0]
     
      Valeur["country"]=Country
    Valeur["year"]=int(data.get("year")) if data.get("year") else None
    if not Valeur["year"]:
        if data.get("firstaired"):
            try:
             Valeur["year"]=int(data.get("firstaired").split("-")[0])
            except:
             Valeur["year"]=None   
        else:
           if data.get("premiered"):
            try:
              Valeur["year"]=int(data.get("premiered").split("-")[0])
            except:
              Valeur["year"]=None
              
    Valeur["top250"]=int(data.get("top250")) if data.get("top250") else None
    Valeur["setid"]=int(data.get("setid")) if data.get("setid") else None
    Valeur["rating"]=float(data.get("rating")) if data.get("rating") else None
    Valeur["userrating"]=int(data.get("userrating")) if data.get("userrating") else None
    Valeur["playcount"]=int(data.get("playcount")) if data.get("playcount") else None
    Valeur["overlay"]=int(data.get("overlay")) if data.get("overlay") else None
    
    if data.get("cast"):
      Casting=[]
      CastingRole=[]
      for xx in data.get("cast"):
        Casting.append(xx["name"])
        CastingRole.append((xx["name"],xx["role"]))      
      Valeur["castandrole"]=CastingRole
      Valeur["cast"]=Casting
    if data.get("director"):
      director=[]
      if len(data.get("director"))>1:
        for xx in data.get("director"):
          director.append(xx)
      else:
        director=data.get("director")[0]
      Valeur["director"]=director
    
    
    Valeur["mpaa"]=data.get("mpaa")
    Valeur["plot"]=data.get("plot")
    Valeur["plotoutline"]=data.get("plotoutline")
    Valeur["title"]=data.get("title")
    Valeur["originaltitle"]=data.get("originaltitle")
    Valeur["duration"]=int(data.get("duration")) if data.get("duration") else None
    if data.get("studio"):
      studio=[]
      if len(data.get("studio"))>1:
        for xx in data.get("studio"):
          studio.append(xx)
      else:
        studio=data.get("studio")[0]
      Valeur["studio"]=studio
    Valeur["tagline"]=data.get("tagline")
    if data.get("writer"):
      writer=[]
      if len(data.get("writer"))>1:
        for xx in data.get("writer"):
          writer.append(xx)
      else:
        writer=data.get("writer")[0]
      Valeur["writer"]=writer
    
    Valeur["tvshowtitle"]=data.get("showtitle")
    Valeur["premiered"]=data.get("premiered")
    Valeur["status"]=data.get("status")
    Valeur["set"]=data.get("set")
    Valeur["firstaired"]=data.get("firstaired")
    Valeur["imdbnumber"]=data.get("imdbnumber")
    if data.get("credits"):
      credits=[]
      if len(data.get("credits"))>1:
        for xx in data.get("credits"):
          credits.append(xx)
      else:
        credits=data.get("credits")[0]
      Valeur["credits"]=credits
    
    Valeur["lastplayed"]=data.get("lastplayed")
    Valeur["votes"]=data.get("votes")
    Valeur["path"]=data.get("file")
    Valeur["trailer"]=data.get("trailer")
    Valeur["dateadded"]=data.get("dateadded")
    
    Valeur["dbid"]=None
    if data.get("movieid"):
      Valeur["dbid"]=int(data.get("movieid"))
      Valeur["mediatype"]="movie"
    if data.get("tvshowid"):
      Valeur["dbid"]=int(data.get("tvshowid"))
    if data.get("episodeid"):
      Valeur["dbid"]=int(data.get("episodeid"))
      Valeur["mediatype"]="tvshow"
      Valeur["episode"]=data.get("episode") if data.get("episode") else None
      Valeur["season"]=data.get("season") if data.get("season") else None
      
    logMsg("Valeur : (%s)" %(Valeur["dbid"]))
    return Valeur
  else:
    return None   



 

def getMovieSetTotaltime(SetID=None):
  TotalRuntime=0
  if SetID:
    
    json_result = getJSON('VideoLibrary.GetMovieSetDetails', '{ "setid":%d,"movies":{"properties": ["runtime"]} }' %(int(SetID)))
    if json_result and json_result.get("movies"): 
           allMovies = json_result.get("movies")
           for item in allMovies:
             Runtime=item.get("runtime")
             logMsg("Runtime (%s)" %(Runtime),0)
             try:
              IRunTime=int(Runtime)
             except:
              IRunTime=0
             TotalRuntime=TotalRuntime+IRunTime
           if TotalRuntime>0:
            TotalRuntime=TotalRuntime/60 
  logMsg("Total saga Runtime (%s)" %(TotalRuntime),0)   
  return TotalRuntime

def GetVolume():
  json_result = getJSON('Application.GetProperties','{"properties":["volume","muted"]}')
  if json_result:
     return json_result.get("volume")

# --------------------------------------------------------------------------------------------------
    
def getJSON(method,params):
    json_response = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method" : "%s", "params": %s, "id":1 }' %(method, str(params)))
    jsonobject = json.loads(json_response)
    
    if(jsonobject.get('result')):
        jsonobject = jsonobject['result']
        
        if jsonobject.get('files'):
            return jsonobject['files']
        elif jsonobject.get('movies'):
            return jsonobject['movies']
        elif jsonobject.get('tvshows'):
            return jsonobject['tvshows']
        elif jsonobject.get('seasons'):
            return jsonobject['seasons']
        elif jsonobject.get('episodes'):
            return jsonobject['episodes']
        elif jsonobject.get('musicvideos'):
            return jsonobject['musicvideos']
        elif jsonobject.get('channels'):
            return jsonobject['channels']
        elif jsonobject.get('recordings'):
            return jsonobject['recordings']
        elif jsonobject.get('timers'):
            return jsonobject['timers']
        elif jsonobject.get('channeldetails'):
            return jsonobject['channeldetails']
        elif jsonobject.get('recordingdetails'):
            return jsonobject['recordingdetails']
        elif jsonobject.get('songs'):
            return jsonobject['songs']
        elif jsonobject.get('albums'):
            return jsonobject['albums']
        elif jsonobject.get('songdetails'):
            return jsonobject['songdetails']
        elif jsonobject.get('albumdetails'):
            return jsonobject['albumdetails']
        elif jsonobject.get('artistdetails'):
            return jsonobject['artistdetails']
        elif jsonobject.get('favourites'):
            return jsonobject['favourites']
        elif jsonobject.get('tvshowdetails'):
            return jsonobject['tvshowdetails']
        elif jsonobject.get('episodedetails'):
            return jsonobject['episodedetails']
        elif jsonobject.get('moviedetails'):
            return jsonobject['moviedetails']
        elif jsonobject.get('setdetails'):
            return jsonobject['setdetails']
        elif jsonobject.get('musicvideodetails'):
            return jsonobject['musicvideodetails']
        elif jsonobject.get('sets'):
            return jsonobject['sets']
        elif jsonobject.get('video'):
            return jsonobject['video']
        elif jsonobject.get('artists'):
            return jsonobject['artists']
        elif jsonobject.get('channelgroups'):
            return jsonobject['channelgroups']
        elif jsonobject.get('sources'):
            return jsonobject['sources']
        elif jsonobject.get('addons'):
            return jsonobject['addons']
        elif jsonobject.get('item'):
            return jsonobject['item']
        elif jsonobject.get('genres'):
            return jsonobject['genres']
        elif jsonobject.get('value'):
            return jsonobject['value']
        else:
            return jsonobject

    else:
        return {}
        
def requestUrlJson(QueryURL,XmlUrl=None):
  
  try:
    req = urllib.request.Request(QueryURL.replace(" ","%20")) 
  except :
    str_response=None
    logMsg("Erreur1  urllib2.Request(QueryURL) --> " + str(QueryURL),0)
  if req:
    user_agent = 'Dalvik/1.6.0 (Linux; U; Android 4.2.2; Nexus 4 Build/JDQ39E)'
    req.add_header('User-agent',user_agent)
             
  try:
    reponse = urllib.request.urlopen(req, timeout = 1)
    #reponse = urllib.request.urlopen(QueryURL, None, 2)
  except:
    reponse=None
    logMsg("Erreur2  urllib2.urlopen(QueryURL) --> " + str(QueryURL),0) 
  
  json_data=None
  if reponse:
        try:
          str_response = reponse.read()
        except :
          str_response=None
          logMsg("Erreur  requestUrlJson introuvable  --> " + str(QueryURL),0)

        if str_response :
            if not XmlUrl:  
              try:
               json_data = json.loads(str_response)
              except:
               json_data=None
               logMsg("Erreur  requestUrlJson  vide --> " + str(QueryURL),0)
            else:
               #xml    = ET.parse(str_response)
               xml=ET.fromstring(str_response)
               jsondata = xml2json.elem2json(xml, None)
               json_data = json.loads(jsondata)
               #json_data = parseXmlToJson(xml)
               
  return json_data
def CheckTMDB():
  QueryURL="https://api.themoviedb.org/3/find/341663?api_key=%s&language=fr&external_source=tvdb_id&include_adult=true" %TMDBApiKey
  json_result = requestUrlJson(QueryURL)
  if json_result:
        return "https://api.themoviedb.org/3/"
  return "http://api.themoviedb.org/3/"

def try_encode(text, encoding="utf8"):
    try:
        return text.encode(encoding,"ignore")
    except:
        return text

def try_decode(text, encoding="utf8"):
    try:
        return text.decode(encoding,"ignore")
    except:
        return text
BaseUrlTMDB=CheckTMDB()