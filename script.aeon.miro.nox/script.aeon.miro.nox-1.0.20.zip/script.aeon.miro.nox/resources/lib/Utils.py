#!/usr/bin/python
# coding: utf-8
#from __future__ import unicode_literals
import xbmcplugin, xbmcgui, xbmc, xbmcaddon, xbmcvfs
import os,sys,io,shutil
from . import youturl
import datetime
import subprocess

import _strptime
import time
import unicodedata
import ssl

from io import open as Fopen

import zipfile

try:
    import zlib
    compression = zipfile.ZIP_DEFLATED
except:
    compression = zipfile.ZIP_STORED

try: #python3
 from urllib.request import Request as URequest
 from urllib import error as Uerror
 from urllib import parse as Uparse
 from urllib.parse import unquote as Uunquote
 from urllib.parse import quote as Uquote
 from urllib.request import urlopen as Uurlopen
 from urllib.parse import parse_qs
 from urllib.request import urlretrieve as Uurlretrieve
 from urllib.error import HTTPError as UHTTPError
 from urllib.request import HTTPSHandler as UHTTPSHandler
 from urllib.request import build_opener as Ubuild_opener
 from urllib.request import install_opener as Uinstall_opener
 from urllib.request import url2pathname as Uurl2pathname
 from urllib.parse import urlencode as Uurlencode
 from urllib.parse import quote as Uquote
 import http.client as httplib
 from html.parser import HTMLParser
 import subprocess
 
except: #python2
  from subprocess import Popen, PIPE, STDOUT
  from urllib2 import urlopen as Uurlopen
  from urllib2 import quote as Uquote
  from urllib  import urlencode as Uurlencode
  from urllib import url2pathname as Uurl2pathname
  from urllib2 import build_opener as Ubuild_opener
  from urllib2 import install_opener as Uinstall_opener
  from urllib2 import HTTPError as UHTTPError
  from urllib2 import Request as URequest
  from urllib2 import HTTPSHandler as UHTTPSHandler
  from urlparse import urlparse as Uparse
  from urlparse import parse_qs
  from urllib import unquote as Uunquote
  from urllib import quote as Uquote
  from urllib import urlretrieve as Uurlretrieve
  import httplib
  import HTMLParser
  

try:
  to_unicode=unicode
except:
  to_unicode=str


import json
import sqlite3
import operator
import locale
import hashlib
import base64
import xml.etree.ElementTree as ET
    

    
try:
  from xbmcvfs import translatePath as translatePath
except:
  from xbmc import translatePath as translatePath
ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = translatePath("special://profile/addon_data/%s" % ADDON_ID)
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])
WINDOW = xbmcgui.Window(10000)
#SETTING = ADDON.getSetting
KODILANGUAGE = xbmc.getInfoLabel( "System.Language" )
KODILANGCODE = xbmc.getLanguage(xbmc.ISO_639_1).lower()
TMDBApiKey="67158e2af1624020e34fd893c881b019"
ListePays={"?":"Inconnu","AF":"Afghanistan","AL":"Albania","DZ":"Algeria","AS":"American Samoa","AD":"Andorra","AO":"Angola","AI":"Anguilla","AQ":"Antarctica","AG":"Antigua and Barbuda","AR":"Argentina","AM":"Armenia","AW":"Aruba","AU":"Australia","AT":"Austria","AZ":"Azerbaijan","BS":"Bahamas","BH":"Bahrain","BD":"Bangladesh","BB":"Barbados","BY":"Belarus",
"BE":"Belgium","BZ":"Belize","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","BO":"Bolivia, Plurinational State of","BA":"Bosnia and Herzegovina","BW":"Botswana","BV":"Bouvet Island","BR":"Brazil","IO":"British Indian Ocean Territory","BN":"Brunei Darussalam","BG":"Bulgaria","BF":"Burkina Faso","BI":"Burundi","KH":"Cambodia","CM":"Cameroon","CA":"Canada","CV":"Cape Verde","KY":"Cayman Islands","CF":"Central African Republic","TD":"Chad",
"CL":"Chile","CN":"China","CX":"Christmas Island","CC":"Cocos (Keeling) Islands","CO":"Colombia","KM":"Comoros","CG":"Congo","CD":"Congo, the Democratic Republic of the","CK":"Cook Islands","CR":"Costa Rica","CI":"Cote d'Ivoire","HR":"Croatia","CU":"Cuba","CY":"Cyprus","CZ":"Czech Republic","DK":"Denmark","DJ":"Djibouti","DM":"Dominica","DO":"Dominican Republic","EC":"Ecuador","EG":"Egypt","SV":"El Salvador","GQ":"Equatorial Guinea","ER":"Eritrea","EE":"Estonia","ET":"Ethiopia","FK":"Falkland Islands (Malvinas)","FO":"Faroe Islands","FJ":"Fiji","FI":"Finland","FR":"France",
"GF":"French Guiana","PF":"French Polynesia","TF":"French Southern Territories","GA":"Gabon","GM":"Gambia","GE":"Georgia","DE":"Germany","GH":"Ghana","GI":"Gibraltar","GR":"Greece","GL":"Greenland","GD":"Grenada","GP":"Guadeloupe","GU":"Guam","GT":"Guatemala","GG":"Guernsey","GN":"Guinea","GW":"Guinea-Bissau","GY":"Guyana","HT":"Haiti","HM":"Heard Island and McDonald Islands","VA":"Holy See (Vatican City State)","HN":"Honduras","HK":"Hong Kong","HU":"Hungary","IS":"Iceland","IN":"India","ID":"Indonesia","IR":"Iran, Islamic Republic of","IQ":"Iraq","IE":"Ireland","IM":"Isle of Man",
"IL":"Israel","IT":"Italy","JM":"Jamaica","JP":"Japan","JE":"Jersey","JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KI":"Kiribati","KP":"Korea, Democratic People's Republic of","KR":"Korea, Republic of","KW":"Kuwait","KG":"Kyrgyzstan","LA":"Lao People's Democratic Republic","LV":"Latvia","LB":"Lebanon","LS":"Lesotho","LR":"Liberia","LY":"Libyan Arab Jamahiriya","LI":"Liechtenstein","LT":"Lithuania","LU":"Luxembourg","MO":"Macao","MK":"Macedonia, the former Yugoslav Republic of","MG":"Madagascar","MW":"Malawi","MY":"Malaysia","MV":"Maldives","ML":"Mali","MT":"Malta","MH":"Marshall Islands","MQ":"Martinique","MR":"Mauritania","MU":"Mauritius","YT":"Mayotte","MX":"Mexico","FM":"Micronesia, Federated States of","MD":"Moldova, Republic of","MC":"Monaco",
"MN":"Mongolia","ME":"Montenegro","MS":"Montserrat","MA":"Morocco","MZ":"Mozambique","MM":"Myanmar","NA":"Namibia","NR":"Nauru","NP":"Nepal","NL":"Netherlands","AN":"Netherlands Antilles","NC":"New Caledonia","NZ":"New Zealand","NI":"Nicaragua","NE":"Niger","NG":"Nigeria","NU":"Niue","NF":"Norfolk Island","MP":"Northern Mariana Islands","NO":"Norway","OM":"Oman","PK":"Pakistan","PW":"Palau","PS":"Palestinian Territory, Occupied","PA":"Panama","PG":"Papua New Guinea","PY":"Paraguay","PE":"Peru","PH":"Philippines","PN":"Pitcairn","PL":"Poland","PT":"Portugal","PR":"Puerto Rico",
"QA":"Qatar","RE":"Reunion","RO":"Romania","RU":"Russian Federation","RW":"Rwanda","BL":"Saint Barthelemy","SH":"Saint Helena, Ascension and Tristan da Cunha","KN":"Saint Kitts and Nevis","LC":"Saint Lucia","MF":"Saint Martin (French part)","PM":"Saint Pierre and Miquelon","VC":"Saint Vincent and the Grenadines","WS":"Samoa","SM":"San Marino","ST":"Sao Tome and Principe","SA":"Saudi Arabia","SN":"Senegal","RS":"Serbia","SC":"Seychelles","SL":"Sierra Leone","SG":"Singapore","SK":"Slovakia","SI":"Slovenia","SB":"Solomon Islands","SO":"Somalia","ZA":"South Africa","GS":"South Georgia and the South Sandwich Islands","ES":"Spain","LK":"Sri Lanka","SD":"Sudan","SR":"Suriname","SJ":"Svalbard and Jan Mayen","SZ":"Swaziland","SE":"Sweden","CH":"Switzerland","SY":"Syrian Arab Republic","TW":"Taiwan, Province of China",
"TJ":"Tajikistan","TZ":"Tanzania, United Republic of","TH":"Thailand","TL":"Timor-Leste","TG":"Togo","TK":"Tokelau","TO":"Tonga","TT":"Trinidad and Tobago","TN":"Tunisia","TR":"Turkey","TM":"Turkmenistan","TC":"Turks and Caicos Islands","TV":"Tuvalu","UG":"Uganda","UA":"Ukraine","AE":"United Arab Emirates","GB":"United Kingdom","US":"United States of America","UM":"United States Minor Outlying Islands","UY":"Uruguay","UZ":"Uzbekistan","VU":"Vanuatu","VE":"Venezuela, Bolivarian Republic of","VN":"Viet Nam","VG":"Virgin Islands, British","VI":"Virgin Islands, U.S.","WF":"Wallis and Futuna","EH":"Western Sahara","YE":"Yemen","ZM":"Zambia","ZW":"Zimbabwe","":"?","00":"?"
}
__skin_string__ = xbmc.getLocalizedString


sys.path.append(translatePath(os.path.join(ADDON_PATH, 'resources', 'lib')))

def DirStru(filename):
   logMsg("Dirstru debut")
   try:
        
        erreur=os.makedirs(os.path.dirname(filename)) 
               
   except: 
        erreur="1"
   logMsg("Dirstru fin")
   return erreur 
   
def logMsg(msg, level = 0): #ca c'est pour debugger. ca ecrit le message MSG dans Kodi.log
    if WINDOW.getProperty("enabledebug") != "" : #or level == 0:
        try:
           if isinstance(msg, unicode):
              msg = msg.encode('utf8')
        except:
          i=0
        if "exception" in msg.lower() or "error" in msg.lower():
            xbmc.log("IconMixToolsMiroNox addon --> " + msg, level=xbmc.LOGERROR)
            #print_exc()
        else:
          try:
            level=xbmc.LOGNOTICE
          except:
            level=xbmc.LOGINFO
          xbmc.log("IconMixToolsMiroNox addon --> " + msg, level=level)

logMsg("nom : %s - %s" %(ADDON_NAME,ADDON_PATH ))
#--------------------------FFPROBE -------------------------------------
def checkpath(path):
  #print "path ->%s" %path
  if "linux" in sys.platform:
          path=path.replace('\\','/')
          path=path.replace('//','/')
  else:
    path=path.replace('/','\\')
  #print "path <-%s" %path  
  return path

"""           
def extract_ffprobe():
  chemin=checkpath(ADDON_PATH+"/resources/lib/ffprobe/")
  #output = subprocess.getoutput("ls /home/telex/.kodi/addons/script.aeon.miro.nox/resources/lib")  
  #logMsg("Chemin Liste : %s" %output)
  
  if "linux" in sys.platform:
          executable="ffprobe"
          #os.system("chmod 777 %s" %chemin)
  else:
          executable="ffprobe.exe"
  if xbmcvfs.exists(chemin+executable):
    return chemin+executable

  try:
    zf = zipfile.ZipFile(chemin+"ffprobe.linux-win.zip")
  except:
    logMsg('Zip archive introuvable %s' %chemin )
    zf=None
    executable=None
  if zf:    
    try:            
        
        zf.extract(executable,chemin) 
        logMsg("Extraction ZIP (%s)" %sys.platform)               
    except KeyError:
        executable=None
        logMsg('ERROR: Did not find %s in zip file' %chemin )
    zf.close()  
    if executable:
      try:
        executable=chemin+executable
        #os.remove(chemin+"ffprobe.linux-win.zip")
        i=0  
      except:
        logMsg("effacement du ZIP impossible !!!!")
  return executable  
""" 

""" 
def getFFprobePath():
  if "linux" in sys.platform:
          commande="which ffprobe"
  else:
          commande="where ffprobe"
  try:
     output = subprocess.getoutput(commande)
  except:
    output=""
    p = Popen(commande, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT, close_fds=True)  
    for line in p.stdout:  
          line = line.rstrip()  
          #print(line)
          output=output+line
  #print("OUTPUT : %s" %output.split('\n')[0])
  if 'ffprobe' in output.lower():
    return output.split('\n')[0]
  else:
    return None
"""  
#FFPROBEPATH=getFFprobePath()  
#FFPROBEPATH=extract_ffprobe()  
  
#------------------------  -------------------------------
def checksavepath(chemin=None):
  if chemin:
    try:
      xbmcvfs.mkdirs(ADDON_DATA_PATH+"/%s" %(chemin))
    except:
      i=0

#------------------------ HDR TEST -------------------------------
"""
def checkHDR(chemin=None,resolution=None,FFPROBEPATH=None):
  if FFPROBEPATH:
    logMsg("Resolution= %s" %resolution)
    if not resolution.lower() in ' 1080 4k 8k':
      return ''
    checkextension=['.mp4','.mkv','.ts','.mpeg','.avi']
    checksavepath(checkpath("/hdrcheck/"))
    savepath=ADDON_DATA_PATH+"/hdrcheck/hdrdata" 
    logMsg("FFPROBEPATH = %s\nchemin=%s\nresolution=%s" %(FFPROBEPATH,chemin, resolution))
    retour=None  
    if FFPROBEPATH and chemin and xbmcvfs.exists(checkpath(chemin)):
      cheminsansaccent=remove_accents(chemin)
      file_name, file_extension = os.path.splitext(chemin.lower())
      logMsg("file_name : %s / file_extension : %s" %(file_name, file_extension))
      if file_extension in checkextension:
        if not '.hdr' in chemin:
          datacheck={}
          try:
            if xbmcvfs.exists(savepath):
              with Fopen(savepath,"r") as fcheck:            
                  datacheck = json.load(fcheck)            
                  fcheck.close()
            retour=datacheck.get(os.path.basename(cheminsansaccent))
          except:
            retour=None
          if retour:
            return retour       
          
          #commande='%s  -hide_banner -show_streams -select_streams V -show_entries "frame=color_space,color_primaries,color_transfer,side_data_list,pix_fmt" -i "%s"' %(FFPROBEPATH,chemin)
          try:
             os.system("chmod 777 %s" %FFPROBEPATH)
          except:
            i=0
          commande='%s -hide_banner -v error -show_format -show_streams -select_streams V "%s"'%(FFPROBEPATH,chemin)
          #logMsg("Commande : %s" %commande)
          try:
             output = subprocess.getoutput(commande)
          except:
            output=""
            p = Popen(commande, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT) #, close_fds=True)  
            for line in p.stdout:  
                  line = line.rstrip()  
                  #logMsg(line)
                  output=output+line
          #logMsg("OUTPUT = %s" %output)
          #retour=subprocess.check_output(['ffprobe', '-show_streams -select_streams v %s' %chemin])
          HDR=""
          if output:
            try:
              retour=output.decode("utf8").lower()
            except:
              retour=output.lower()
            #logMsg("retour : %s" %retour)
            if 'smtpe2094' in retour or 'hdr10+' in retour:
              HDR="HDR10plus"
              logMsg("BINGO !!!! HDR10+ !!!")
            elif "color_space=bt2020nc" in retour or "color_transfer=smpte2084" in retour or "color_primaries=bt2020" in retour:
              logMsg("BINGO !!!! HDR !!!")
              HDR="HDR10"
                
              
          datacheck[os.path.basename(cheminsansaccent)]=HDR
          with io.open(savepath, 'w', encoding='utf8',errors='ignore') as outfile: 
            str_ = json.dumps(datacheck,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
            outfile.write(to_unicode(str_))
            outfile.close()
          return HDR
        else:
          return 'HDR10'
  return ''
"""
#
    
def getCasting(Castingtypex=None,ItemId=None,Statique=None,MissingId=None):
  allCast = None
  item = {}
  Casting = []
  CastingKodi=None
  Castingtype=""
  imageacteur="" 
  ListeActeur=[]
  if not 'movie' in Castingtypex:
    Typex="tv"
  else:
    Typex="movie"
  
  
  NonVide=xbmc.getCondVisibility("Skin.HasSetting(HideMovieTvCastEmpty)")
  #videodb://movies/actors/1132/   1132=id acteur pour retrouver ses films
  
  if  (len(sys.argv)>1 and sys.argv[1]) or Statique:
      if Castingtypex and ( ItemId or MissingId ):   
         #if Castingtypex=="episode":            Castingtypex="tvshow"
    
         Castingtype="VideoLibrary.Get%sDetails" %(Castingtypex)
         MissingThumbnail=[]
         if ItemId: # and not MissingId:
           if not "set" in Castingtypex:
            
             json_result = getJSON(Castingtype, '{ "%sid":%d,"properties": [ "cast","uniqueid"]}' %(Castingtypex,int(ItemId)))
             logMsg("GetCasting KODI : (%s)" %json_result)
             if json_result:
               CastingKodi=json_result.get("cast")
               MissingThumbnail=[]
               for item in CastingKodi:
                 if not item.get("thumbnail"):
                   MissingThumbnail.append(item)    
               
               if not MissingId:
                 MissingId=get_TMDBID(DbType=Castingtypex,KodiId=None,UniqueId=json_result.get("uniqueid"))
                 logMsg("MissingId = %s" %MissingId)
               
                   
               #logMsg("CastingKodi = %s" %CastingKodi)
               logMsg("MissingThumbnail = %s" %MissingThumbnail)
           else:
             #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovieSetDetails","params":{"setid":7,"movies":{"properties":["uniqueid"]}},"id":"1"}
             json_result = getJSON("VideoLibrary.GetMovieSetDetails", '{ "%sid":%d,"movies":{"properties":["uniqueid"]}}' %(Castingtypex,int(ItemId)))
             collectionid=None
             if json_result:
               try:
                 uniqueid=json_result.get("movies")[0].get("uniqueid")
                 logMsg("uniqueid= %s" %uniqueid) 
                 if uniqueid:
                   tmdbid=get_TMDBID(DbType=Castingtypex,KodiId=None,UniqueId=uniqueid)
                   logMsg("tmdbid= %s" %tmdbid) 
                   if tmdbid:
                     QueryURL="%smovie/%s?api_key=%s&include_adult=true" %(BaseUrlTMDB,tmdbid,TMDBApiKey)
                     logMsg("TMDB collection ID->%s" %QueryURL)
                     json_data = requestUrlJson(QueryURL)
                     if json_data:
                       collectionid=json_data.get("belongs_to_collection").get("id")
                       
                       
               except:
                 collectionid=None
             if collectionid:
               logMsg("CollectionID= %s" %collectionid)
               htmldata=getHtmlFromUrl("https://www.themoviedb.org/collection/%s" %collectionid)
               if htmldata: 
                try:
                  listeacteurs=htmldata.split('<ol class="people mini">')[1].split('</ol>')[0].split('<li class="card">')
                  listeacteurs.pop(0)
                  CastingKodi=[]
                  cpt=1
                  for item in listeacteurs:
                    nom=item.split('alt="')[1].split('"')[0]
                    role=item.split('character">')[1].split('</p>')[0]
                    photo=item.split('face/')[1].split('"')[0]
                    if photo:
                      photo="http://image.tmdb.org/t/p/original/"+photo
                    CastingKodi.append({'name':nom,'role':role,'thumbnail':photo,'order':cpt})
                    cpt=cpt+1 
                    
                except:
                  listeacteurs=None
                logMsg("CastingKodi : %s" %CastingKodi)   
         #if MissingId and len(MissingThumbnail)>0:
         if MissingId and (len(MissingThumbnail)>0 or not CastingKodi):
            if not 'movie' in Castingtypex:
              Typex="tv"
            else:
              Typex="movie"
            QueryURL="%s%s/%s/credits?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,Typex,MissingId,TMDBApiKey,KODILANGCODE) 
            #QueryURL="%s%s/%s/credits" % (BaseUrlTMDB,Typex,MissingId)
            #Data={'api_key':TMDBApiKey,'language':KODILANGCODE,'include_adult':True}
            logMsg("CastingKodi missing thumbnail ->")   
            json_result = requestUrlJson(QueryURL=QueryURL)
            if json_result:
              castingTMDB=json_result.get("cast")
              if CastingKodi:
                castingTMDBImage={}
                for item in castingTMDB:
                  image=item.get('profile_path')
                  if image:
                    castingTMDBImage[item.get('name').lower()]="http://image.tmdb.org/t/p/original"+str(image)
                #logMsg("castingTMDBImage = %s" %castingTMDBImage)
                CastingKodi2=CastingKodi
                CastingKodi=[]
                for item in CastingKodi2:
                  if not item.get("thumbnail"):
                    name=item.get('name')
                    item['thumbnail']=castingTMDBImage.get(name.lower())                  
                    
                  CastingKodi.append(item)
              else:    
                logMsg("CastingKodi vide ->")            
                CastingKodi=[]                
                cpt=1 
                for item in castingTMDB:
                  nom=item.get("name")
                  role=item.get("character")
                  photo=item.get("profile_path")
                  if photo:
                    photo="http://image.tmdb.org/t/p/original"+photo
                  CastingKodi.append({'name':nom,'role':role,'thumbnail':photo,'order':cpt})
                  cpt=cpt+1      
            

         
            
         if CastingKodi:
           for item in CastingKodi:
             name=item.get("name")
             if Castingtypex=="episode":
              if int(item.get("order"))==0 and item.get("role")=="": #directeur
                name=None
             
             if name :
                 
                 imageacteur=str(item.get("thumbnail"))
                 
                 if not imageacteur:
                    imageacteur="defaultactor.png"
                 #else :
                 if imageacteur:
                     imageacteur=Uunquote(imageacteur).replace("image://","")
                     #imageacteur=imageacteur.replace("image://","") 
                     if imageacteur[len(imageacteur)-1]=='/':
                        imageacteur=imageacteur[:-1]
                     label2x=item.get("role")
                     if not label2x:
                       label2x=item.get("character")
                     #logMsg("%s : %s" %(name,imageacteur))
                     ItemListe = xbmcgui.ListItem(label=name,label2=label2x)
                     ItemListe.setArt({'icon':imageacteur,'thumb':imageacteur,'poster':imageacteur})
                     
                     ItemListe.setProperty("DbType","acteurs")
                     if not Statique:
                         ListeActeur.append(["",ItemListe,True])
                     else:
                         ListeActeur.append(ItemListe)
                         
  if not Statique:
     xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeActeur)
     xbmcplugin.endOfDirectory(int(sys.argv[1]))
  else:
     return ListeActeur         
     
def get_TMDBID(DbType=None,KodiId=None,UniqueId=None):
   externalXX=None
   ItemIdR=None
   
   if not UniqueId and KodiId and DbType:
      if DbType=="episode":
        json_result = getJSON("VideoLibrary.GetEpisodeDetails",'{"episodeid":%d,"properties":["tvshowid"]}' %(int(KodiId)))
        if json_result:
          KodiId=json_result.get("tvshowid")
        else :
          return None
         
         
      json_result = getJSON("VideoLibrary.Get%sDetails" %(DbType), '{"%sid":%d,"properties":["uniqueid"]}' %(DbType,int(KodiId)))
      if json_result:
        UniqueId=json_result.get("uniqueid")
        
   
   
   if UniqueId:
       IMDBNUMBER=UniqueId.get("imdb")
       try:
        TMDBNUMBER=int(UniqueId.get("tmdb"))
       except:
        TMDBNUMBER=None
       TVDBNUMBER=UniqueId.get("tvdb")
       UNKNNUMBER=UniqueId.get("unknown")
       if TMDBNUMBER:
         return str(TMDBNUMBER)
       elif TVDBNUMBER:
         externalXX="tvdb_id"
         ItemId=str(TVDBNUMBER)
       elif IMDBNUMBER:
         if str(IMDBNUMBER).find('tt')==-1:
           externalXX=None
         else:
           externalXX="imdb_id"
           ItemId=str(IMDBNUMBER)
       else:
         externalXX=None
       
   if externalXX:
     query_url = "%sfind/%s?api_key=%s&language=%s&external_source=%s&include_adult=true" % (BaseUrlTMDB,ItemId,TMDBApiKey,KODILANGCODE,externalXX) 
     #logMsg("get_TMDBID(%s)" %query_url)    
     json_data = requestUrlJson(query_url)
     ItemIdR=str(ItemId) 
     if json_data:
           if DbType!="movie": 
            allID=json_data.get("tv_results")
           else:
            allID=json_data.get("movie_results")
           if allID and len(allID)>0:
               for item in allID:
                     ItemIdR=item.get("id")
                     break
     #logMsg("json_data (%s)(%s)" %(ItemId,json_data))
   if ItemIdR:  
     return str(ItemIdR)
   else:
    return None
   
        

     
def ActeurFilmsTvKODI(ActeurType=None,Acteur=None,Statique=None,KodiID=None,TypeID=None):
  Donnees = []
  item = {}
  Casting = []
  RechercheType=""
  VideoPoster="" 
  ListeVideos=[]
  #checkitem=["art","cast","country","dateadded","director","episode","episodeid","fanart","file","firstaired","genre","imdbnumber","lastplayed","mpaa","originaltitle","playcount","plot","plotoutline","productioncode","rating","ratings","resume","runtime","season","seasonid","set","setid","showlink","showtitle","sorttitle","specialsortepisode","specialsortseason","streamdetails","studio","tag","tagline","thumbnail","title","top250","trailer","tvshowid","uniqueid","userrating","votes","writer","year"]
  #checkitemok=[]
  
  #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"filter":{"actor":"marion cotillard"},"properties":["thumbnail","year","file"]},"id":"1"}
  #videodb://movies/actors/1132/   1132=id acteur pour retrouver ses films
  if  (len(sys.argv)>1 and sys.argv[1]) or Statique:
      if Acteur or (KodiID and TypeID):
         if not KodiID:
           if ActeurType and ActeurType=="director":
              Ok=""
           else: ActeurType="actor"
          
           Acteur=Remove_Separator(Acteur)
           #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"filter":{"field":"director","operator":"contains","value":"ridley"},"properties":["thumbnail","year","file"]},"id":"1"}       
           json_result = getJSON("VideoLibrary.GetMovies", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["art", "cast", "country", "dateadded", "director", "fanart", "file", "genre", "imdbnumber", "lastplayed", "mpaa", "originaltitle", "playcount", "plot", "plotoutline", "rating", "ratings", "resume", "runtime", "set", "setid", "showlink", "sorttitle", "streamdetails", "studio", "tag", "tagline", "thumbnail", "title", "top250", "trailer", "uniqueid", "userrating", "votes", "writer", "year"]}' %(ActeurType,Acteur))
           json_result2 = getJSON("VideoLibrary.GetTvShows", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["art", "cast", "dateadded", "episode", "fanart", "file", "genre", "imdbnumber", "lastplayed", "mpaa", "originaltitle", "playcount", "plot", "rating", "ratings", "runtime", "season", "sorttitle", "studio", "tag", "thumbnail", "title", "uniqueid", "userrating", "votes", "year"]}' %(ActeurType,Acteur))
             
           if len(json_result)>0:
            Donnees=json_result
            #logMsg("Donnees 1 : %s" %Donnees)
           if len(json_result2)>0:
            #logMsg("Donnees 2 : %s" %json_result2)
            Donnees=Donnees+json_result2
            #Donnees=[*Donnees,*json_result2] #python3
            
         else:
           Donnees=getJSON('VideoLibrary.Get%sDetails' %(TypeID), '{ "%sid":%d,"properties": ["%sid","art", "cast", "country", "dateadded", "director", "fanart", "file", "genre", "imdbnumber", "lastplayed", "mpaa", "originaltitle", "playcount", "plot", "plotoutline", "rating", "ratings", "resume", "runtime", "set", "setid", "showlink", "sorttitle", "streamdetails", "studio", "tag", "tagline", "thumbnail", "title", "top250", "trailer", "uniqueid", "userrating", "votes", "writer", "year"  ]}' %(TypeID,int(KodiID),TypeID))
           logMsg("Donnees Kodi Json : %s" %Donnees)
         
                  
         if Donnees:
           logMsg("DONNEES : %s" %Donnees)
           for Item in Donnees:
             try:
                Titre=Item.get("label")
             except:
              Titre=None
             if Titre:
                 ItemListe = xbmcgui.ListItem(label=Titre)
                 ItemListe.setArt({'icon':Item.get("art").get("poster")})
                 ItemListe.setProperty("poster",Item.get("art").get("poster")) 
                 Casting = Item.get("cast")
                 #logMsg("Casting : %s" %Casting)
                 if Casting:
                    for ItemCast in  Casting:
                         if ItemCast.get("name")==Acteur:
                              ItemListe.setLabel2(ItemCast.get("role"))
                              ItemListe.setProperty('role',ItemCast.get("role"))
                              break  
                 
                 IdVideo=Item.get("movieid")
                 TypeVideo="movie"
                 if not IdVideo: 
                    IdVideo=Item.get("tvshowid")
                    TypeVideo="tvshow"
                 ItemListe.setArt( Item.get("art"))
                 Fanart=Item.get("art").get("fanart")
                 if Fanart:
                     ItemListe.setProperty("fanart",Fanart)
                 else:
                     ItemListe.setProperty("fanart","")
                 
                 ItemListe.setProperty('DBID', str(IdVideo))
                 ItemListe.setProperty('dbtype',TypeVideo)
                 ItemListe.setProperty('IMDBNumber', str(Item.get("imdbnumber")))
                 try:
                   TMDBNUMBER=Item.get("uniqueid").get("tmdb")
                   ItemListe.setProperty("TMDBNumber",str(TMDBNUMBER))
                 except:
                   i=0
                 ItemListe.setProperty('Rating',str(int(Item.get("rating")))) 
                 UserRating=Item.get("userrating")
                 if UserRating:
                     if int(UserRating)>0:
                       ItemListe.setProperty('UserRating',str(int(Item.get("userrating"))))
                     else:
                       ItemListe.setProperty('UserRating','')
                 
                 #pistes audios tele
                 try:
                   Audio=Item.get("streamdetails").get("audio")
                 except:
                   Audio=None
                 i=1
                 if Audio:               
                       for AudioElement in Audio:
                            ItemListe.setProperty('AudioLanguage.%d' %(i), AudioElement.get("language").lower())
                            ItemListe.setProperty('AudioChannels.%d' %(i), str(AudioElement.get("channels")).lower())
                            ItemListe.setProperty('AudioCodec.%d' %(i), AudioElement.get("codec").lower()) 
                            ItemListe.addStreamInfo('audio',AudioElement)                   
                            i=i+1
            
                  #pistes vid�os 
                 try:
                   Video=Item.get("streamdetails").get("video")
                 except:
                   Video=None
                 i=0
                 Codec=""
                 if Video:
                    #{"aspect":2.3975000381469726563,"codec":"h264","duration":5584,"height":800,"language":"eng","stereomode":"","width":1918}
                    for VideoItem in Video:
                       ItemListe.setProperty('VideoCodec', VideoItem.get("codec")) 
                       ItemListe.addStreamInfo('video',VideoItem)
                       
                  #sous-titres  
                 try:   
                   Subtitles=Item.get("streamdetails").get("subtitle")
                 except:
                   Subtitles=None
                 i=1
                  
                 if Subtitles:
                       for SubtitleElement in Subtitles:
                            ItemListe.setProperty('SubtitleLanguage.%d' %(i), SubtitleElement.get("language"))  
                            ItemListe.addStreamInfo('subtitle',SubtitleElement)                   
                            i=i+1
                 Genre=Item.get("genre")               
                 if Genre:
                  listegenre=""
                  for IGenre in Genre:
                    #listegenre.append(tmdbgenre.get(str(IGenre )))
                    if listegenre!="":
                      listegenre=listegenre+','
                    listegenre=listegenre+IGenre
                  Item["genre"]=listegenre  
                  
                 InfoLabels=GetListItemInfoLabelsJson(Item)
                 if InfoLabels:
                   InfoLabels["mediatype"]= TypeVideo
                   ItemListe.setInfo("video", InfoLabels)
                   ItemListe.setPath(Item.get("file"))
                   if not Statique:
                       ListeVideos.append([Item.get("file"),ItemListe,False])
                   else:
                       #ListeVideos.append(ItemListe)
                       try:
                            Annee=Item.get("year")
                       except:
                            Annee="0"
                       if not Annee or Annee=="":
                        Annee="0" 
                       ListeVideos.append([int(Annee),ItemListe])
                 
  
  if not Statique:               
     xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeVideos)       
     xbmcplugin.endOfDirectory(int(sys.argv[1])) 
  else:
     ListeItemFinal=[]
     LL=[]
     #logMsg("tri debut")               
     LL=sorted(ListeVideos, key=lambda x:x[0],reverse=True)
     #logMsg("Tri par Annee")
     #tri par ann�e
     cpt=0
     while cpt<len(LL):
             ListeItemFinal.append(LL[cpt][1])
             cpt=cpt+1
           
     return ListeItemFinal

def ActeurFilmsTvTMDB(ActeurType=None,Acteur=None,Statique=None,TmdbID=None,TypeID=None):
  allInfo = []
  item = {}
  Casting = []
  Castingtype=""
  imageacteur="" 
  ListeRoles=[]
  ListeId=[]
  ActeurId={}
  ActeurCache={}
  json_data=None
  logMsg("ActeurFilmsTvTMDB (%s)" %Acteur)
  
  ActeurSave=1
  ActeurCache["nom"]=None
  ActeurCache["id"]=None
  if ActeurType and ActeurType=="director":
            ActeurType='realisateurs'
            ActeurCache["crew"]=[]
  else: ActeurType="acteurs"
  if ActeurType and Acteur!="None": 
     
     if Acteur:
        tmdbgenre=GetTMDBGenres()
        Acteur=Remove_Separator(Acteur)
        ActeurCache["cast"]=[] 
        #checksavepath(ActeurType)
        check=remove_accents(Acteur)
        savepath=checkpath(ADDON_DATA_PATH+"/%s/%s" %(ActeurType,check.replace(" ", "_")))
        
        #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,str(unidecode(Acteur)).replace(" ", "_"))
        if savepath and xbmcvfs.exists(savepath):
          with Fopen(savepath,encoding='utf-8') as data_file:
                  json_data = json.load(data_file)
                  ActeurSave=0
                  data_file.close()
                  if not json_data.get("cast") or not json_data.get("checkcastV7") or (ActeurType=="realisateurs" and not json_data.get("crew")):
                    ActeurSave=1
                  #if not json_data.get("biographie"):  
                  #  json_data=json_data+GetActeurInfo(Acteur)
                  #  ActeurSave=1
                  if json_data:                      
                      ActeurCache["biographie"]=json_data.get("biographie")
                      ActeurCache["naissance"]=json_data.get("naissance")                  
                      ActeurCache["deces"]=json_data.get("deces")                                                 
                      ActeurCache["lieunaissance"]=json_data.get("lieunaissance")
                      ActeurCache["nom"]=json_data.get("nom")
                      ActeurCache["nomreel"]=json_data.get("nomreel")
                      ActeurCache["id"]=json_data.get("id")
          ActeurId=json_data.get("id")
        else:
          ActeurId=GetActeurId(Acteur) 
        
        if savepath and ActeurId.get("tmdb") and (not xbmcvfs.exists(savepath) or ActeurSave>0):
            QueryURL = "%sperson/%s/combined_credits?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey,KODILANGCODE) 
            logMsg("QueryTMDB (%s)" %QueryURL)
            json_data = requestUrlJson(QueryURL)
            ActeurCache["checkcastV7"]="ok"
         
        if json_data: 
                  
                  Donnees=None
                  if ActeurType!='realisateurs':
                    Donnees=json_data.get("cast")
                  if ActeurType=='realisateurs':
                    Donnees=json_data.get("crew")
                    
                  if Donnees:
                                     
                    for item in Donnees:  
                                          
                       TypeVideo=str(item.get("media_type"))
                       """
                       if not item.get('overview') or item.get('overview')=="":
                          QueryURL = "%s%s/%s?api_key=%s&language=en&include_adult=true" % (BaseUrlTMDB,TypeVideo,item.get('id'),TMDBApiKey)
                          logMsg("Overview vide! -> %s" %item)
                          logMsg("Overview vide! -> %s" %QueryURL)
                          json_data2 = requestUrlJson(QueryURL)
                          if json_data2:
                            item['overview']=json_data2.get('overview') 
                       """
                       name=""                     
                       if TypeVideo=="movie": name=item.get("title")
                       else : name=item.get("name")
                       if name:                         
                         IdFix=item.get("id")
                         
                         
                         Ajout=1
                         if IdFix:
                            if not IdFix in ListeId:
                               ListeId.append(IdFix)                                                     
                            else:
                               Ajout=0
                         if Ajout>0:                                                                                
                              Poster=item.get("poster_path")
                              if not Poster:
                                Poster=item.get("backdrop_path")
                              if not Poster:                                  
                                 if TypeVideo=="movie": Poster="defaultmovietitle.png"
                                 else: Poster="defaulttvshowtitle.png"
                              else: Poster="http://image.tmdb.org/t/p/original"+str(Poster)
                              
                              if TypeVideo=="tv":
                                TypeVideo="tvshow"
                              
                              if ActeurType!='realisateurs':
                                ActeurCache["cast"].append(item)
                                Role=item.get("character")
                              if ActeurType=='realisateurs':
                                ActeurCache["crew"].append(item)
                                Role=item.get("job")
                              if not Role:
                                 Role="?"
                              
                              ItemListe = xbmcgui.ListItem(label=name,label2=Role)
                              ItemListe.setArt({'icon':Poster})
                              ItemListe.setProperty("poster",Poster)
                              ItemListe.setProperty("role",Role)
                              ItemListe.setArt({"poster":Poster})
                              Fanart=item.get("backdrop_path")
                              if Fanart:
                                 Fanart=Uunquote("http://image.tmdb.org/t/p/original"+Fanart)
                                 ItemListe.setProperty("fanart",Fanart)
                              else:
                                 Fanart=""
                                 
                              try:
                                Annee=item.get("release_date").split("-")[0]
                              except:
                                Annee=None
                              if not Annee:
                                 try: 
                                   Annee=item.get("first_air_date").split("-")[0]
                                 except:
                                   Annee="0"
                              if not Annee or Annee=="":
                                Annee="0"
                             
                              
                              try:
                                Rating=float(item.get("vote_average"))
                              except:
                                Rating=None
                              #logMsg("TmdbRating : %s" %Rating)
                              try:
                                  ItemPays=item.get("origin_country")
                              except:
                                  ItemPays=None
                              if ItemPays:
                                Pays=[]
                                for paysitem in ItemPays:
                                  if paysitem:
                                    if len(paysitem)<4:
                                      Pays.append(ListePays.get(paysitem.upper()).encode("utf8"))
                                    else:
                                      Pays.append(paysitem.upper().encode("utf8"))
                                
                              else:
                                  Pays=None
                              Genre=item.get("genre_ids")                              
                              listegenre=""
                              if Genre:
                                for IGenre in Genre:
                                  addgenre=tmdbgenre.get(str(IGenre ))
                                  #listegenre.append(tmdbgenre.get(str(IGenre )))
                                  if addgenre:
                                    if listegenre!="":
                                      listegenre=listegenre+','
                                    #logMsg("listegenre : %s" %listegenre)
                                    #logMsg("tmdbgenre : %s / %s" %(IGenre,tmdbgenre))
                                    listegenre=listegenre+addgenre
                              
                              ItemListe.setProperty("TMDBNumber",str(IdFix))
                              #ItemListe.setProperty('Rating',Rating) 
                              ItemListe.setProperty("dbtype",TypeVideo.replace("id",""))
                              ItemListe.setArt({'poster':Poster,'fanart':Fanart,'landscape':Fanart,'icon':Poster})
                              ItemListe.setInfo("video", {"title": name,"genre": listegenre,"mediatype": TypeVideo.replace("id",""),"rating":Rating,"year": Annee,"originaltitle": item.get("original_title"),"trailer":item.get("id"),"plot":item.get("overview"),"country":Pays})        
                              ItemListe.setPath(None)
                              """
                              if TmdbID and TypeID:
                                if TmdbID==IdFix and TypeID==TypeVideo:
                                  ListeRoles.append([int(Annee),ItemListe])
                                  logMsg("Retour TMDB Unique : %s / %s" %(Annee,Name))
                                  break
                              """
                              if not Statique:
                                 ListeRoles.append(["",ItemListe,True])
                              else :
                                 #ListeRoles.append(ItemListe)
                                 ListeRoles.append([int(Annee),ItemListe])
                         
                            
                  if not TmdbID and savepath and ActeurSave>0:
                        #erreur=DirStru(savepath)
                        #ActeurCache["cast"]=json_data.get("cast") 
                        #ActeurCache["crew"]=json_data.get("crew")  
                        
                        if not ActeurCache["nom"]: ActeurCache["nom"]=str(Acteur)                         
                        if not ActeurCache["id"]: ActeurCache["id"]=ActeurId    
                        try:                    
                          with io.open(savepath, 'w', encoding='utf8',errors='ignore') as outfile: 
                            str_ = json.dumps(ActeurCache,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
                            outfile.write(to_unicode(str_)) 
                        except:
                          logMsg("Erreur ActeurFilmsTvTMDB io.open (%s)" %(savepath) ) 
                          
                  if not Statique:     
                      xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeRoles)
                                      
  if not Statique:
      xbmcplugin.endOfDirectory(int(sys.argv[1])) 
  else:
     ListeItemFinal=[]
     LL=[]          
     #LL=sorted(ListeRoles,reverse=True)
     LL=sorted(ListeRoles, key=lambda x:x[0],reverse=True)
     #tri par ann�e
     cpt=0
     while cpt<len(LL):
             ListeItemFinal.append(LL[cpt][1])
             cpt=cpt+1
           
     return ListeItemFinal 
     
def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD',  try_decode(input_str))
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)])
    
def Remove_Separator(Chaine=None):
  if Chaine:
    Chaine=Chaine.split("/")[0].rstrip()
    Chaine=Chaine.split("&")[0].rstrip()
    Chaine=Chaine.split(",")[0].rstrip()
    Chaine=Chaine.replace('"','')
    Chaine=Chaine.replace("'",'')
  return Chaine
"""  
def checksavepath(chemin=None):
  if chemin:
    try:
      xbmcvfs.mkdirs(ADDON_DATA_PATH+"/%s" %(chemin))
    except:
      i=0
"""      
def GetTMDBGenres():
  globalgenre={}
  #checksavepath(ADDON_DATA_PATH)
  savepath=checkpath(ADDON_DATA_PATH+"/tmdbgenres")
  if xbmcvfs.exists(savepath):
    with Fopen(savepath,encoding='utf-8') as data_file:
      try:
        globalgenre = json.load(data_file)
      except:
        globalgenre=""
       
  if len(globalgenre)<1:  
    QueryURL="https://api.themoviedb.org/3/genre/movie/list?api_key=67158e2af1624020e34fd893c881b019&language=%s" %KODILANGCODE
    json_data = requestUrlJson(QueryURL)
    globalgenre={}
    if json_data:
      for item in json_data.get("genres"):
        globalgenre[str(item.get("id"))]=item.get("name")   
    
    QueryURL="https://api.themoviedb.org/3/genre/tv/list?api_key=67158e2af1624020e34fd893c881b019&language=%s" %KODILANGCODE
    json_data = requestUrlJson(QueryURL)
    if json_data:
      for item in json_data.get("genres"):
        globalgenre[str(item.get("id"))]=item.get("name")
    
    
    
    with io.open(savepath, 'w', encoding='utf8',errors='ignore') as outfile: 
        str_ = json.dumps(globalgenre,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
        outfile.write(to_unicode(str_)) 
    #logMsg("TMDBGENRES OK")
  return globalgenre


    

def getTMDBMovieDetails(IDVIDEO=None,DBTYPE=None,KodiDB=None,InfoTag=None):
  infomovie={}
  if DBTYPE and IDVIDEO and not KodiDB:
    if 'movie' in DBTYPE.lower():
      DBTYPE='movie'
    else:
      DBTYPE='tv'
    #QueryURL="%s%s/%s?api_key=%s&language=%s&include_adult=true" %(BaseUrlTMDB,DBTYPE,IDVIDEO,TMDBApiKey,KODILANGCODE)
    
    QueryURL="%s%s/%s?api_key=%s&language=en&include_adult=true&append_to_response=credits,videos" %(BaseUrlTMDB,DBTYPE,IDVIDEO,TMDBApiKey)
    logMsg("TMDB duree/overview/fanart->%s" %QueryURL)
    json_data = requestUrlJson(QueryURL)
    if json_data:
      infomovie["duree"]=json_data.get('runtime')
      infomovie["overview"]=json_data.get('overview')
      infomovie["fanart"]="http://image.tmdb.org/t/p/original"+str(json_data.get("backdrop_path")) 
      #https://api.themoviedb.org/3/movie/293660/credits?api_key=67158e2af1624020e34fd893c881b019&language=en-US
      #QueryURL="%s%s/%s/credits?api_key=%s&language=%s&include_adult=true" %(BaseUrlTMDB,DBTYPE,IDVIDEO,TMDBApiKey,KODILANGCODE)
      #logMsg("TMDB Cast->%s" %QueryURL)
      #json_data = requestUrlJson(QueryURL)
      #if json_data:
      donnees=json_data.get("cast")
      Acteurs=[]
      if donnees:
        cpt=1 
        for item in donnees:
          nom=item.get("name")
          role=item.get("character")
          photo=item.get("profile_path")
          if photo:
            photo="http://image.tmdb.org/t/p/original"+photo
          Acteurs.append({'name':nom,'role':role,'thumbnail':photo,'order':cpt})
          cpt=cpt+1  
      data=getOneTrailer(ID=IDVIDEO,DbType=DBTYPE,SaisonID=None)
      #data=None
      if data:
        try:
          infomovie['trailer']=data[0].get('url') 
        except:
          i=0     
      infomovie['Acteurs']=Acteurs
      logMsg("retour (TMDB) getTMDB%sDetails (%d) : %s" %(DBTYPE,int(IDVIDEO),infomovie ))
  else:
    Castingtype="VideoLibrary.Get%sDetails" %(DBTYPE)    
    json_result = getJSON(Castingtype, '{ "%sid":%d,"properties": [ "cast","uniqueid"]}' %(DBTYPE,int(IDVIDEO)))
    logMsg("retour Kodi getTMDB%sDetails (%d) : %s" %(DBTYPE,int(IDVIDEO),json_result ))
    if json_result:
      return json_result.get('cast')
    else:
      return None
  return infomovie
            
  
  

def getOneTrailer(ID=None,DbType=None,SaisonID=None):
     Donnees=[]
     ListeTrailer=[]
     #https://api.themoviedb.org/3/movie/$$IDFILM$$/videos?api_key=67158e2af1624020e34fd893c881b019&language=French      
     #https://api.themoviedb.org/3/tv/$$IDTV$$/videos?api_key=67158e2af1624020e34fd893c881b019&language=French  
     #https://api.themoviedb.org/3/search/tv?api_key=67158e2af1624020e34fd893c881b019&language=en-US&query=American%20Horror%20Story&page=1
     

     
     if ID:
        if DbType: 
          MediaQualite=720 #par defaut
          #logMsg("getTrailer (%s)(%s)" %(DbType,ID))
          if DbType!="movie":
               QueryURL ="%stv/%s/videos?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey,KODILANGCODE)
          else:
               QueryURL ="%smovie/%s/videos?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey,KODILANGCODE)
          logMsg("Trailer QueryURL : %s" %QueryURL)
          json_data = requestUrlJson(QueryURL) #en francais
          if json_data:
            Donnees=json_data.get("results")               
          if DbType!="movie":
               QueryURL ="%stv/%s/videos?api_key=%s&language=en&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey)
          else:
               QueryURL ="%smovie/%s/videos?api_key=%s&language=en&include_adult=true" % (BaseUrlTMDB,ID,TMDBApiKey)
          #logMsg("getTrailer (%s)(%s)(%s)" %(DbType,ID,QueryURL))
          json_data = requestUrlJson(QueryURL) #en anglais
          logMsg("Trailer QueryURL2 : %s" %QueryURL)
          if json_data:
            Donnees=Donnees+json_data.get("results") 
            #{"id":181808,"results":[{"id":"59dca043c3a368623e070253","iso_639_1":"fr","iso_3166_1":"FR","key":"_pkhEAC8YTU","name":"Bande Annonce VOST","site":"YouTube","size":1080,"type":"Trailer"}]}         
          logMsg("Trailer donnees : %s" %Donnees)
          if Donnees:
               cc=0
               for Item in Donnees:
                    #{"id":"56609361c3a36875e00047c2","iso_639_1":"en","iso_3166_1":"US","key":"ScY179qa5pM","name":"Season 5 (Hotel) Opening","site":"YouTube","size":1080,"type":"Opening Credits"}
                    try:               
                      ItemSize=int(Item.get("size"))
                    except:
                      ItemSize=720 #par d�faut
                    try:
                      TypeTrailer=Item.get("type").lower()
                    except:
                      TypeTrailer=""
                    try:
                      Site=Item.get("site").lower()
                    except:
                      Site=""  
                      
                    if SaisonID:
                      Nom=Item.get("name")
                      if Nom:
                        data=re.search(r"Season (.{1,3}) ", Nom)
                        if data:
                          try:
                            SaisonTMDB=int(data.group(1))
                          except:
                            SaisonTMDB=0
                          if SaisonTMDB!=int(SaisonID):
                            Site="rejet"
                    logMsg("YT TypeTrailer (%s)(%s)(%s)(%s)(%s)" %(ID,TypeTrailer,Item.get("key"),Site,ItemSize),0)
                    #if Site=="youtube" and ItemSize>=MediaQualite and (TypeTrailer=="trailer" or not AnnonceUniquement):
                    if Site=="youtube" and ItemSize>=MediaQualite and TypeTrailer=="trailer":
                         urlyoutube=youturl.getyoutubeurl(Item["key"])
                         if urlyoutube:
                           Item["url"]=urlyoutube                         
                           Item["position"]=str(cc) 
                           Item["id"]='plugin://plugin.video.youtube/play/?video_id=%s' %(Item["key"])                         
                           Item["landscape"]="http://img.youtube.com/vi/%s/hqdefault.jpg" %(Item["key"])
                           logMsg("urlyoutube : (%s) (%s)" %(Item["key"],urlyoutube))
                           Item["key"]="YouTube"                         
                           ListeTrailer.append(Item)                           
                           logMsg("ListeTrailer : %s" %ListeTrailer)
                           break
     #logMsg("ListeTrailer : %s" %ListeTrailer)
     return ListeTrailer
       
def GetActeurId(Acteur):
    
  ActeurId={}
  if Acteur and Acteur!="None":  
        #allocine pour les frenchies ;)
        #ActeurId["allocine"]=''
        #Acteur=try_decode(Acteur.split("(")[0])
        #ActeurId["allocine"]=Allocine_ChercheActeur(Acteur)
        
          #TMDB   
        try:
          check=Acteur.encode('utf8')
        except:
          check=Acteur 
        QueryURL = "%ssearch/person?api_key=%s&language=%s&query=%s&page=1&include_adult=true" % (BaseUrlTMDB,TMDBApiKey,KODILANGCODE,Uquote(check))
        logMsg("getacteurid : QueryURL (%s)" %(QueryURL))
        logMsg("getacteurid : QueryURL (%s)" %(Uunquote(QueryURL)))
        json_data = requestUrlJson(Uunquote(QueryURL))              
        ActeurId["tmdb"]=None        
        if json_data:
            allInfo=json_data.get("results")            
            
            if allInfo:
              for item in allInfo:
                if not ActeurId["tmdb"]:
                   ActeurId["tmdb"]=str(item.get("id"))
                   logMsg("GetActeurId ActeurTMDBID (%s)" %(str(ActeurId["tmdb"])),0)
                break
  #logMsg("retour GetActeurId")
  return ActeurId 

def GetActeurInfo(NomActeur,ActeurType="acteurs"):
  ActeurCache={}
  ActeurId={}
  Bio=None
  json_data={}
  SaveActeur=0
  
  if ActeurType and "director" in ActeurType:
            ActeurType='realisateurs'
  if ActeurType and "actor" in ActeurType:
            ActeurType='acteurs'
  if NomActeur and ActeurType:
    NomActeur=Remove_Separator(NomActeur)
    
    check=remove_accents(try_decode(NomActeur))
    #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,remove_accents(NomActeur.encode("utf8","ignore").decode("utf8","ignore").replace(" ", "_")))
    #NomActeur=NomActeur.encode("utf8","ignore").decode("utf8","ignore")
    #checksavepath(ActeurType)
    try:
      savepath=checkpath(ADDON_DATA_PATH+"/%s/%s" %(ActeurType,check.replace(" ", "_")))
    except:
      savepath=None
    
    if xbmcvfs.exists(savepath):
        with Fopen(savepath,encoding='utf-8') as data_file:
                  try:
                    json_data = json.load(data_file)
                  except:
                    json_data=None
                  data_file.close() 
                  if json_data:
                      ActeurCache["cast"]=json_data.get("cast") 
                      ActeurId=json_data.get("id")
                      Bio='biographie' in json_data
                      if not json_data.get("v6"):
                        Bio=None
                       
                      #Bio=json_data.get("biographie")
                      
                  
   
    
    if not Bio or not ActeurId :
          if not ActeurId :            
            ActeurId=GetActeurId(NomActeur)
          if ActeurId:
            json_data=GetActeurInfoMaj(ActeurId,NomActeur)
            #logMsg("BIOGRAPHIE : %s " %json_data.get("biographie"))
          else:
            return ActeurCache          
           
    if json_data : 
              ActeurCache["biographie"]=json_data.get("biographie")
              ActeurCache["naissance"]=json_data.get("naissance")                  
              ActeurCache["deces"]=json_data.get("deces")                                                 
              ActeurCache["lieunaissance"]=json_data.get("lieunaissance")
              ActeurCache["nom"]=try_decode(json_data.get("nom"))
              ActeurCache["nomreel"]=try_decode(json_data.get("nomreel"))
              ActeurCache["poster"]=json_data.get("poster")
              ActeurCache["id"]=ActeurId
              ActeurCache["v6"]="ok"
              if savepath:
                  #logMsg("GetActeurInfo savepath : %s" %savepath )
                  erreur=DirStru(savepath) 
                  try:           
                    with io.open(savepath, 'w+', encoding='utf8',errors='ignore') as outfile: 
                      str_ = json.dumps(ActeurCache,indent=4, sort_keys=True,separators=(',', ':'), ensure_ascii=False)
                      outfile.write(to_unicode(str_))
                  except:
                    logMsg("Erreur GetActeurInfo io.open (%s)" %(savepath) )
  return ActeurCache

def GetActeurInfoMaj(ActeurId,NomActeur):
  #http://www.imdb.com/xml/find?json=1&nr=1&nm=on&q=Cynthia%20Addai-Robinson
  json_data={}
  json_datatmdb={}
  ActeurCache={}
  if ActeurId:
    if NomActeur:
      ActeurCache["nom"]=NomActeur
    if KODILANGUAGE[0:4]=='Fren' and ActeurId.get("allocine"):
          if (ActeurId["allocine"]!='') :        
            #si pas de bio en francais  et language de Kodi est French 
            json_datax=Allocine_Acteur(ActeurId.get("allocine"))
            
            if json_datax:
              
              jsonacteurdata=json.loads(json_datax)             
              if jsonacteurdata and KODILANGUAGE[0:4]=='Fren':
                      jsonActeur=jsonacteurdata.get("person")
                      if jsonActeur:
                        json_data["name"]=NomActeur 
                        json_data["realName"]=jsonActeur.get("realName")
                        json_data["biography"]=jsonActeur.get("biography")
                        json_data["birthday"]=jsonActeur.get("birthDate")      
                        json_data["deathday"]=''                                                 
                        json_data["place_of_birth"]=jsonActeur.get("birthPlace")
                        try:
                          json_data["poster"]=jsonActeur.get("picture")["href"] 
                        except:
                          json_data["poster"]=None
                        #ActeurId='allo'+str(AllocineId)                     
            
    if ActeurId.get("tmdb"):
        if not json_data.get("biography"):           
          #on recherche sur tmdb dans la langue de KODI
            QueryURL = "%sperson/%s?api_key=%s&language=%s&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey,KODILANGCODE) 
            #logMsg("get BIOGRAPHIE :%s" %QueryURL)
            json_datatmdb = requestUrlJson(QueryURL) 
        try:
          biobio=json_data.get("biography")
        except:
          biobio=None
        try:
          biobio2=json_datatmdb.get("biography")
        except:
          biobio2=None
        
            
        if not json_datatmdb or (not biobio and not biobio2):   
              #pas de biographie dans la langue de KODI alors on cherche en Anglais......
              QueryURL = "%sperson/%s?api_key=%s&language=EN&include_adult=true" % (BaseUrlTMDB,ActeurId.get("tmdb"),TMDBApiKey) 
              json_datatmdb = requestUrlJson(QueryURL)
          
       
    if json_data or json_datatmdb: 
          if json_data and json_data.get("biography"):
             ActeurCache["biographie"]=json_data.get("biography")
          else:
             if not json_datatmdb:
              ActeurCache["biographie"]=""
             else:
              ActeurCache["biographie"]=json_datatmdb.get("biography")
             
          if json_data and json_data.get("birthday"):
             ActeurCache["naissance"]=json_data.get("birthday")
          else:
             if not json_datatmdb:
              ActeurCache["naissance"]=""
             else:
              ActeurCache["naissance"]=json_datatmdb.get("birthday")
             
          if json_data and json_data.get("deathday"):
             ActeurCache["deces"]=json_data.get("deathday")
          else:
             if not json_datatmdb:
              ActeurCache["deces"]=""
             else:
              ActeurCache["deces"]=json_datatmdb.get("deathday")
             
          if json_data and json_data.get("place_of_birth"):
             ActeurCache["lieunaissance"]=json_data.get("place_of_birth")
          else:
             if not json_datatmdb:
              ActeurCache["lieunaissance"]=""
             else:
              ActeurCache["lieunaissance"]=json_datatmdb.get("place_of_birth")
             
          if json_data and json_data.get("name"):
             ActeurCache["nom"]=json_data.get("name")
          else:
             if not json_datatmdb:
              ActeurCache["nom"]=""
             else:
              ActeurCache["nom"]=json_datatmdb.get("name")
             
          if json_data and json_data.get("realName"):
             ActeurCache["nomreel"]=json_data.get("realName")
          else:
             if not json_datatmdb:
              ActeurCache["nomreel"]=""
             else:
              ActeurCache["nomreel"]=json_datatmdb.get("realName")
          
          
        
          
          if json_data and json_data.get("poster"):
             ActeurCache["poster"]=json_data.get("poster")
          else:
             if not json_datatmdb:
              ActeurCache["poster"]=""
             else:
              if json_datatmdb.get("profile_path"):
                ActeurCache["poster"]="http://image.tmdb.org/t/p/original"+json_datatmdb.get("profile_path") 

                
  return ActeurCache  
    
def GetPhotoRealisateur(CheminType="",realisateur=None,HttpUniquement=None):
    allInfo = []
    realisateurId=""
    savepath=""   
    Poster=None  
    #savepath=ADDON_DATA_PATH+"/%s/%s" %(ActeurType,str(unidecode(NomActeur)).replace(" ", "_"))
    
    if realisateur and len(realisateur)>4: 
          realisateur=Remove_Separator(realisateur)
          zig=try_decode(realisateur).replace('"','')
          check=remove_accents(zig.replace(" ", "_"))
          savepath=checkpath(ADDON_DATA_PATH+"/%s/%s" %(CheminType,check))
          if xbmcvfs.exists(savepath+".jpg"):
              return(savepath+".jpg")
              
          if xbmcvfs.exists(savepath):
              with Fopen(savepath,encoding='utf-8') as data_file:
                  try:
                    json_data = json.load(data_file)
                  except:
                    json_data=None
                  data_file.close() 
                  Poster=None
                  if json_data:
                      Poster=json_data.get("poster") 
                      if savepath:
                        return Poster
                      #Bio=json_data.get("biographie")
          
          if not Poster and savepath:  
             Poster="defaultactor.png" 
             Cache=GetActeurInfo(zig,CheminType)
             if Cache :
                Poster=Cache.get("poster")
                
                
                if (CheminType=="realisateurs" or CheminType=="acteurs"):
                   QueryURL=Poster
                   try:            
                     #logMsg("GetPhotoRealisateur savepath : %s" %savepath )          
                     erreur=DirStru(savepath+".jpg")
                     Uurlretrieve(QueryURL,savepath+".jpg")
                   except :
                     str_response=''
                     Poster="defaultactor.png"

    return(Poster if Poster else "defaultactor.png") 
#------------------------------------

# --------------------------------------------UTILITAIRES/PLUGIN----------------------------------------------
def Remove_Separator(Chaine=None):
  if Chaine:
    Chaine=Chaine.split("/")[0].rstrip()
    Chaine=Chaine.split("&")[0].rstrip()
    Chaine=Chaine.split(",")[0].rstrip()
    Chaine=Chaine.replace('"','')
    Chaine=Chaine.replace("'",'')
  return Chaine  

def GetListItemInfoLabelsJson(data=None):
    
  if data:
    Valeur={}
    
    Valeur["genre"]=data.get("genre")
    if data.get("country"):
      Country=[]
      if len(data.get("country"))>1:
        for xx in data.get("country"):
          Country.append(xx)
      else:
        Country=data.get("country")[0]
     
      Valeur["country"]=Country
    Valeur["year"]=int(data.get("year")) if data.get("year") else None
    
              
    Valeur["top250"]=int(data.get("top250")) if data.get("top250") else None
    Valeur["setid"]=int(data.get("setid")) if data.get("setid") else None
    Valeur["rating"]=float(data.get("rating")) if data.get("rating") else None
    Valeur["userrating"]=int(data.get("userrating")) if data.get("userrating") else None
    Valeur["playcount"]=int(data.get("playcount")) if data.get("playcount") else None
    Valeur["overlay"]=int(data.get("overlay")) if data.get("overlay") else None
    
    if data.get("cast"):
      Casting=[]
      CastingRole=[]
      for xx in data.get("cast"):
        Casting.append(xx["name"])
        CastingRole.append((xx["name"],xx["role"]))      
      Valeur["castandrole"]=CastingRole
      Valeur["cast"]=Casting
    if data.get("director"):
      director=[]
      if len(data.get("director"))>1:
        for xx in data.get("director"):
          director.append(xx)
      else:
        director=data.get("director")[0]
      Valeur["director"]=director
    
    
    Valeur["mpaa"]=data.get("mpaa")
    Valeur["plot"]=data.get("plot")
    Valeur["plotoutline"]=data.get("plotoutline")
    Valeur["title"]=data.get("title")
    Valeur["originaltitle"]=data.get("originaltitle")
    Valeur["duration"]=int(data.get("duration")) if data.get("duration") else None
    if data.get("studio"):
      studio=[]
      if len(data.get("studio"))>1:
        for xx in data.get("studio"):
          studio.append(xx)
      else:
        studio=data.get("studio")[0]
      Valeur["studio"]=studio
    Valeur["tagline"]=data.get("tagline")
    if data.get("writer"):
      writer=[]
      if len(data.get("writer"))>1:
        for xx in data.get("writer"):
          writer.append(xx)
      else:
        writer=data.get("writer")[0]
      Valeur["writer"]=writer
    
    Valeur["tvshowtitle"]=data.get("showtitle")
    Valeur["premiered"]=None
    Valeur["status"]=data.get("status")
    Valeur["set"]=data.get("set")
    #Valeur["firstaired"]=None
    Valeur["imdbnumber"]=data.get("imdbnumber")
    if data.get("credits"):
      credits=[]
      if len(data.get("credits"))>1:
        for xx in data.get("credits"):
          credits.append(xx)
      else:
        credits=data.get("credits")[0]
      Valeur["credits"]=credits
    
    Valeur["lastplayed"]=data.get("lastplayed")
    Valeur["votes"]=data.get("votes")
    Valeur["path"]=data.get("file")
    Valeur["trailer"]=data.get("trailer")
    Valeur["dateadded"]=data.get("dateadded")
    
    Valeur["dbid"]=None
    if data.get("movieid"):
      Valeur["dbid"]=int(data.get("movieid"))
      Valeur["mediatype"]="movie"
    if data.get("tvshowid"):
      Valeur["dbid"]=int(data.get("tvshowid"))
    if data.get("episodeid"):
      Valeur["dbid"]=int(data.get("episodeid"))
      Valeur["mediatype"]="tvshow"
      Valeur["episode"]=data.get("episode") if data.get("episode") else None
      Valeur["season"]=data.get("season") if data.get("season") else None
      
    #logMsg("Valeur : (%s)" %(Valeur["dbid"]))
    return Valeur
  else:
    return None   



def getMovieSetTotaltime(SetID=None):
  TotalRuntime=0
  if SetID:
    
    json_result = getJSON('VideoLibrary.GetMovieSetDetails', '{ "setid":%d,"movies":{"properties": ["runtime"]} }' %(int(SetID)))
    if json_result and json_result.get("movies"): 
           allMovies = json_result.get("movies")
           for item in allMovies:
             Runtime=item.get("runtime")
             #logMsg("Runtime (%s)" %(Runtime),0)
             try:
              IRunTime=int(Runtime)
             except:
              IRunTime=0
             TotalRuntime=TotalRuntime+IRunTime
           if TotalRuntime>0:
            TotalRuntime=TotalRuntime/60 
  #logMsg("Total saga Runtime (%s)" %(TotalRuntime),0)   
  return TotalRuntime

def GetVolume():
  json_result = getJSON('Application.GetProperties','{"properties":["volume","muted"]}')
  if json_result:
     return json_result.get("volume")

# --------------------------------------------------------------------------------------------------
    
def getJSON(method,params):
    json_response = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method" : "%s", "params": %s, "id":1 }' %(method, str(params)))
    jsonobject = json.loads(json_response)
    
    if(jsonobject.get('result')):
        jsonobject = jsonobject['result']
        
        if jsonobject.get('files'):
            return jsonobject['files']
        elif jsonobject.get('movies'):
            return jsonobject['movies']
        elif jsonobject.get('tvshows'):
            return jsonobject['tvshows']
        elif jsonobject.get('seasons'):
            return jsonobject['seasons']
        elif jsonobject.get('episodes'):
            return jsonobject['episodes']
        elif jsonobject.get('musicvideos'):
            return jsonobject['musicvideos']
        elif jsonobject.get('channels'):
            return jsonobject['channels']
        elif jsonobject.get('recordings'):
            return jsonobject['recordings']
        elif jsonobject.get('timers'):
            return jsonobject['timers']
        elif jsonobject.get('channeldetails'):
            return jsonobject['channeldetails']
        elif jsonobject.get('recordingdetails'):
            return jsonobject['recordingdetails']
        elif jsonobject.get('songs'):
            return jsonobject['songs']
        elif jsonobject.get('albums'):
            return jsonobject['albums']
        elif jsonobject.get('songdetails'):
            return jsonobject['songdetails']
        elif jsonobject.get('albumdetails'):
            return jsonobject['albumdetails']
        elif jsonobject.get('artistdetails'):
            return jsonobject['artistdetails']
        elif jsonobject.get('favourites'):
            return jsonobject['favourites']
        elif jsonobject.get('tvshowdetails'):
            return jsonobject['tvshowdetails']
        elif jsonobject.get('episodedetails'):
            return jsonobject['episodedetails']
        elif jsonobject.get('moviedetails'):
            return jsonobject['moviedetails']
        elif jsonobject.get('setdetails'):
            return jsonobject['setdetails']
        elif jsonobject.get('musicvideodetails'):
            return jsonobject['musicvideodetails']
        elif jsonobject.get('sets'):
            return jsonobject['sets']
        elif jsonobject.get('video'):
            return jsonobject['video']
        elif jsonobject.get('artists'):
            return jsonobject['artists']
        elif jsonobject.get('channelgroups'):
            return jsonobject['channelgroups']
        elif jsonobject.get('sources'):
            return jsonobject['sources']
        elif jsonobject.get('addons'):
            return jsonobject['addons']
        elif jsonobject.get('item'):
            return jsonobject['item']
        elif jsonobject.get('genres'):
            return jsonobject['genres']
        elif jsonobject.get('value'):
            return jsonobject['value']
        else:
            return [] #jsonobject

    else:
        return []
        
def requestUrlJson(QueryURL,XmlUrl=None,GetHtml=None):
  req=None
  try:
    req = URequest(QueryURL.replace(" ","%20")) 
  except :
    str_response=None
    logMsg("Erreur1  urllib2.Request(QueryURL) --> " + str(QueryURL),0)
  
  if req and not GetHtml:
    user_agent = 'Dalvik/1.6.0 (Linux; U; Android 4.2.2; Nexus 4 Build/JDQ39E)'
    req.add_header('User-agent',user_agent)
             
  try:
    reponse = Uurlopen(req, timeout = 2)
  except:
    reponse=None
    logMsg("Erreur2  urllib2.urlopen(QueryURL) --> " + str(QueryURL),0) 
  
  json_data=None
  if reponse:
        try:
          str_response = reponse.read()
        except :
          str_response=None
          logMsg("Erreur  requestUrlJson introuvable  --> " + str(QueryURL),0)

        if str_response :
            if not XmlUrl:  
              try:
               json_data = json.loads(str_response)
              except:
               json_data=None
               logMsg("Erreur  requestUrlJson  vide --> " + str(QueryURL),0)
            elif GetHtml:
              json_data=str_response
            else:
               #xml    = ET.parse(str_response)
               xml=ET.fromstring(str_response)
               jsondata = xml2json.elem2json(xml, None)
               json_data = json.loads(jsondata)
               #json_data = parseXmlToJson(xml)
               
  return json_data
  
def getHtmlFromUrl(url=None):
  
  userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:24.0) Gecko/20100101 Firefox/24.0"  
  headers = { "User-Agent" : userAgent }
  myRequest = URequest(url, data=None, headers=headers)
   
  context = ssl.create_default_context()
  myHTTPSHandler = UHTTPSHandler(context=context)
  myOpener = Ubuild_opener(myHTTPSHandler)
  Uinstall_opener(myOpener)  
  data=None
  try: 
      response = Uurlopen(myRequest) 
      data=response.read()
  except ValueError as e: 
      if hasattr(e, 'code'): # HTTPError 
          logMsg('http error code: ', e.code )
      elif hasattr(e, 'reason'): # URLError 
          logMsg("can't connect, reason: ", e.reason)
  logMsg("GetCineSeries (%s)" %url)    
  return str(data)
  
def CheckTMDB():
  QueryURL="https://api.themoviedb.org/3/find/341663?api_key=%s&language=fr&external_source=tvdb_id&include_adult=true" %TMDBApiKey
  json_result = requestUrlJson(QueryURL)
  #logMsg("CHECKTMDB = %s" %json_result)
  if json_result:
        return "https://api.themoviedb.org/3/"
  return "http://api.themoviedb.org/3/"

def try_encode(text, encoding="utf8"):
    try:
        return text.encode(encoding,"ignore")
    except:
        return text

def try_decode(text, encoding="utf8"):
    try:
        return text.decode(encoding,"ignore")
    except:
        return text
BaseUrlTMDB=CheckTMDB()