﻿# coding: utf-8
#from __future__ import unicode_literals
import resources.lib.Utils as utils
from resources.lib.Utils import logMsg as logMsg
#from resources.lib.Utils import checkHDR
from resources.lib.utilsinfoservice import *
from datetime import datetime,timedelta
import _strptime

import time
from time import sleep
import unicodedata
import os
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,xbmcvfs
import random
try:
  from xbmcvfs import translatePath as translatePath
except:
  from xbmc import translatePath as translatePath
from threading import Thread
import threading
# Script constantes
ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = translatePath("special://profile/addon_data/%s" % ADDON_ID)
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])




def in_hours_and_min(minutes_string):
    try:
        full_minutes = int(minutes_string)
        minutes = full_minutes % 60
        hours   = full_minutes // 60
        return str(hours) + 'h' + str(minutes).zfill(2)
    except:
        return None
#---- TELEX 15/04/2019 ----
class Player(xbmc.Player):

  #------------------------------------------------------------------------------------------------------------------
  def play(self, item='', listitem=None, windowed=False, sublist=None,VolumeBA=None):
      self.Volume=VolumeBA #volume de lecture du theme/bande annonce
      self.VolumeOrg=utils.GetVolume() #sauvegarde du volume actuel
      #xbmc.executebuiltin("SetVolume(%d,true)" %self.Volume)
      utils.logMsg("Lancement de la lecture : %s (%s)(%s)" %(str(item),self.VolumeOrg,self.Volume))
      super(Player, self).play(item, listitem, windowed)  
   

  #------------------------------------------------------------------------------------------------------------------
  def __init__(self):
      self.windowhome = xbmcgui.Window(10000)
      self.windowvideo = xbmcgui.Window(10025)
      self.Volume=None      
      xbmc.Player.__init__(self,0)

  #------------------------------------------------------------------------------------------------------------------
  def onPlayBackStarted(self):        
      if self.Volume:
           utils.logMsg("reglage du volume de lecture")
           xbmc.executebuiltin("SetVolume(%d,true)" %self.Volume) 
     

  #------------------------------------------------------------------------------------------------------------------
  def onPlayBackStopped(self):
      utils.logMsg("arret de la lecture")
      if self.Volume and self.VolumeOrg:
           utils.logMsg("retablissement du volume apres lecture (%s)" %self.VolumeOrg)
           xbmc.executebuiltin("SetVolume(%d,true)" %self.VolumeOrg) #retablissement volume original
      
      
      

  
class InfoServiceDaemon:

    def __init__(self):
        log("version %s started" % ADDON_VERSION)
        self._init_vars()
        #self.run_backend()

    def _init_vars(self):
        self.id = None
        self.type = False
        self.Artist_mbid = None
        self.previousitem = ""
        self._stop = False
        self.WND = xbmcgui.Window(12003)  # Video info dialog
        self.HOME = xbmcgui.Window(10000)  # Home Window

    def run_backend(self):
        
        
        #while (not self._stop) and (not xbmc.Monitor().abortRequested()):
            if xbmc.getCondVisibility("[Window.IsActive(videoosd) + Skin.String(SkinInfo.AutoCloseVideoOSD)] | [Window.IsActive(musicosd) + Skin.String(SkinInfo.AutoCloseMusicOSD)]"):
                if xbmc.getCondVisibility("Window.IsActive(videoosd)"):
                    seconds = xbmc.getInfoLabel("Skin.String(SkinInfo.AutoCloseVideoOSD)")
                    window = "videoosd"
                elif xbmc.getCondVisibility("Window.IsActive(musicosd)"):
                    seconds = xbmc.getInfoLabel("Skin.String(SkinInfo.AutoCloseMusicOSD)")
                    window = "musicosd"
                else:
                    seconds = ""
                if seconds and seconds != "0" and xbmc.getCondVisibility("System.IdleTime(%s)" % seconds) and xbmc.getCondVisibility("Window.IsActive(%s)" % window):
                    logMsg("SkinInfo close window")
                    xbmc.executebuiltin("Dialog.Close(%s)" % window)

            if xbmc.getCondVisibility("Container.Content(movies) | Container.Content(sets) | ListItem.IsCollection | String.IsEqual(ListItem.DBTYPE,set) | Container.Content(artists) | Container.Content(albums) | Container.Content(episodes) | Container.Content(musicvideos)"):
                self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
                if (self.selecteditem != self.previousitem):
                    self.previousitem = self.selecteditem
                    if (self.selecteditem!=""):
                        if xbmc.getCondVisibility("Container.Content(artists)"):
                            self._set_artist_details(self.selecteditem)
                        elif xbmc.getCondVisibility("Container.Content(albums)"):
                            self._set_album_details(self.selecteditem)
                        elif xbmc.getCondVisibility("ListItem.IsCollection | String.IsEqual(ListItem.DBTYPE,set)"):
                            self._set_movieset_details(self.selecteditem)
                        elif xbmc.getCondVisibility("Container.Content(movies)"):
                            self._set_movie_details(self.selecteditem)
                        elif xbmc.getCondVisibility("Container.Content(episodes)"):
                            self._set_episode_details(self.selecteditem)
                        elif xbmc.getCondVisibility("Container.Content(musicvideos)"):
                            self._set_musicvideo_details(self.selecteditem)
                        else:
                            clear_properties()
                    else:
                        clear_properties()

            elif xbmc.getCondVisibility("Container.Content(seasons) + !Window.IsActive(movieinformation)"):
                self.HOME.setProperty("SeasonPoster", xbmc.getInfoLabel("ListItem.Icon"))
                self.HOME.setProperty("SeasonID", xbmc.getInfoLabel("ListItem.DBID"))
                self.HOME.setProperty("SeasonNumber", xbmc.getInfoLabel("ListItem.Season"))
            elif xbmc.getCondVisibility("Window.IsActive(videos) + [Container.Content(directors) | Container.Content(actors) | Container.Content(genres) | Container.Content(years) | Container.Content(studios) | Container.Content(countries) | Container.Content(tags)]"):
                self.selecteditem = xbmc.getInfoLabel("ListItem.Label")
                if (self.selecteditem != self.previousitem):
                    clear_properties()
                    self.previousitem = self.selecteditem
                    if (self.selecteditem != "") and xbmc.getCondVisibility("!ListItem.IsParentFolder"):
                        self.setMovieDetailsforCategory()
            elif xbmc.getCondVisibility("Container.Content(years) | Container.Content(genres)"):
                self.selecteditem = xbmc.getInfoLabel("ListItem.Label")
                if (self.selecteditem != self.previousitem):
                    clear_properties()
                    self.previousitem = self.selecteditem
                    if (self.selecteditem != "") and xbmc.getCondVisibility("!ListItem.IsParentFolder"):
                        self.setMusicDetailsforCategory()
            elif xbmc.getCondVisibility('Window.IsActive(screensaver)'):
                xbmc.Monitor().waitForAbort(1)
            else:
                self.previousitem = ""
                self.selecteditem = ""
                clear_properties()
                xbmc.sleep(500)

            if xbmc.getCondVisibility("String.IsEmpty(Window(home).Property(skininfos_daemon_running))"):
                clear_properties()
                self._stop = True

    def _set_artist_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "AudioLibrary.GetAlbums", "params": {"properties": ["title", "year", "albumlabel", "playcount", "art"], "sort": { "method": "label" }, "filter": {"artistid": %s} }, "id": 1}' % dbid)
        clear_properties()
        if ("result" in json_response) and ('albums' in json_response['result']):
            set_artist_properties(json_response)

    def _set_movie_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"properties": ["streamdetails","set","setid","cast"], "movieid":%s }, "id": 1}' % dbid)
        clear_properties()
        if ("result" in json_response) and ('moviedetails' in json_response['result']):
            self._set_properties(json_response['result']['moviedetails'])

    def _set_episode_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodeDetails", "params": {"properties": ["streamdetails","tvshowid","season"], "episodeid":%s }, "id": 1}' % dbid)
        clear_properties()
        if ('result' in json_response) and ('episodedetails' in json_response['result']):
            self._set_properties(json_response['result']['episodedetails'])
            seasonnumber = json_response['result']['episodedetails']['season']
            tvshowid = json_response['result']['episodedetails']['tvshowid']
            json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "VideoLibrary.GetSeasons", "params": {"properties": ["thumbnail"], "tvshowid":%s }, "id": 1}' % tvshowid)
            for season in json_response["result"]["seasons"]:
                if season["label"].split(" ")[-1] == str(seasonnumber):
                    self.HOME.setProperty('SkinInfo.SeasonPoster', season["thumbnail"])

    def _set_musicvideo_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMusicVideoDetails", "params": {"properties": ["streamdetails"], "musicvideoid":%s }, "id": 1}' % dbid)
        clear_properties()
        if ("result" in json_response) and ('musicvideodetails' in json_response['result']):
            self._set_properties(json_response['result']['musicvideodetails'])

    def _set_album_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "AudioLibrary.GetSongs", "params": {"properties": ["title", "track", "duration", "file", "lastplayed", "disc"], "sort": { "method": "label" }, "filter": {"albumid": %s} }, "id": 1}' % dbid)
        clear_properties()
        if ("result" in json_response) and ('songs' in json_response['result']):
            set_album_properties(json_response)

    def _set_movieset_details(self, dbid):
        json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieSetDetails", "params": {"setid": %s, "properties": [ "thumbnail" ], "movies": { "properties":  [ "rating", "art", "file", "year", "director", "writer", "genre", "thumbnail", "runtime", "studio", "mpaa", "plotoutline", "plot", "country", "streamdetails"], "sort": { "order": "ascending",  "method": "year" }} },"id": 1 }' % dbid)
        clear_properties()
        if ("result" in json_response) and ('setdetails' in json_response['result']):
            set_movie_properties(json_response)

    def setMovieDetailsforCategory(self):
        if xbmc.getCondVisibility("!ListItem.IsParentFolder"):
            count = 1
            path = xbmc.getInfoLabel("ListItem.FolderPath")
            json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "%s", "media": "video", "properties": ["art"]}, "id": 1}' % (path))
            if ("result" in json_response) and ("files" in json_response["result"]):
                for movie in json_response["result"]["files"]:
                    self.HOME.setProperty('SkinInfo.Detail.Movie.%i.Path' % (count), movie["file"])
                    self.HOME.setProperty('SkinInfo.Detail.Movie.%i.Art(fanart)' % (count), movie["art"].get('fanart', ''))
                    self.HOME.setProperty('SkinInfo.Detail.Movie.%i.Art(poster)' % (count), movie["art"].get('poster', ''))
                    count += 1
                    if count > 19:
                        break

    def setMusicDetailsforCategory(self):
        if xbmc.getCondVisibility("!ListItem.IsParentFolder"):
            count = 1
            path = xbmc.getInfoLabel("ListItem.FolderPath")
            json_response = Get_JSON_response('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "%s", "media": "music", "properties": ["fanart", "thumbnail"]}, "id": 1}' % (path))
            if ("result" in json_response) and ("files" in json_response["result"]):
                for artist in json_response["result"]["files"]:
                    if "id" in artist:
                        self.HOME.setProperty('SkinInfo.Detail.Music.%i.DBID' % (count), str(artist["id"]))
                        self.HOME.setProperty('SkinInfo.Detail.Music.%i.Art(fanart)' % (count), artist["fanart"])
                        self.HOME.setProperty('SkinInfo.Detail.Music.%i.Art(thumb)' % (count), artist["thumbnail"])
                        count += 1
                        if count > 19:
                            break

    def _set_properties(self, results):
        # Set language properties
        count = 1
        audio = results['streamdetails']['audio']
        subtitles = results['streamdetails']['subtitle']
        subs = []
        streams = []
        # Clear properties before setting new ones
        clear_properties()
        for item in audio:
            if str(item['language']) not in streams:
                streams.append(str(item['language']))
                self.WND.setProperty('SkinInfo.AudioLanguage.%d' % count, item['language'])
                self.WND.setProperty('SkinInfo.AudioCodec.%d' % count, item['codec'])
                self.WND.setProperty('SkinInfo.AudioChannels.%d' % count, str(item['channels']))
                count += 1
        count = 1
        for item in subtitles:
            if str(item['language']) not in subtitles:
                subs.append(str(item['language']))
                self.WND.setProperty('SkinInfo.SubtitleLanguage.%d' % count, item['language'])
                count += 1
        self.WND.setProperty('SkinInfo.SubtitleLanguage', " / ".join(subs))
        self.WND.setProperty('SkinInfo.AudioLanguage', " / ".join(streams))
        self.WND.setProperty('SkinInfo.SubtitleLanguage.Count', str(len(subs)))
        self.WND.setProperty('SkinInfo.AudioLanguage.Count', str(len(streams)))
        
class ShowInfoDialog(Thread):

    def __init__(self, MonItem=None,parent=None):
        Thread.__init__(self)        
        self.MonItem=MonItem
        self.Parent=parent       

    def run(self):
        dialog = xbmcgui.Dialog()
        #logMsg("Debut du Thread : %s" %self.MonItem.getLabel())
        dialog.info(self.MonItem)
        logMsg("Fin du Thread (windowinfohistory = %s" %self.Parent.windowinfohistory)
        return        
        """
        logMsg("Fin du Thread (windowinfohistory = %s" %self.Parent.windowinfohistory)
        try:
          #self.Parent.windowinfohistory.pop()
          logMsg("POP!= (%d) %s" %(len(self.Parent.windowinfohistory),self.Parent.windowinfohistory))
        except:
          i=0
        #self.Parent.closethread=True
        """
    
class MainService:
  
    #------------------------------------------------------------------------------------------------------------------
  def __init__(self):         
      
      self.kodimonitor = xbmc.Monitor()
      self.ThreadInfo=None
      self.windowhome = xbmcgui.Window(10000) # self.HOME.xml 
      self.windowvideonav = xbmcgui.Window(10025) # myvideonav.xml           
      self.windowvideoinf = xbmcgui.Window(12003) # dialogvideoinfo.xml 
      self.windowhome.setProperty('videoinfopointer','%s' %self.windowvideoinf)
      self.windowvideoplayer = xbmcgui.Window(12901) # videoOSD.xml 
      try:
        self.windowvideoplayerinfo = xbmcgui.Window(10142) # DialogFullScreenInfo.xml
      except:
        self.windowvideoplayerinfo = None
      self.previousselecteditem=None
      self.previousvideoinfo=None
      self.duration = None
      self.closethread=None
      self.previousitem1998 = ""
      self.selecteditem1998 = ""
      self.Position1998=0
      self.previousitem1998local = ""
      self.previousitem8889 = ""
      self.windowinfohistory=[]
      self.lastinfo=None
      self.keephistory=[]
      if (KODI_VERSION>=19):
        self.skininfoservice=InfoServiceDaemon()
        logMsg("self.skininfoservice actif")
      else:
        self.skininfoservice=None
      #----TELEX 15/04/2019
      self.LectureTheme=None
      POS5051=None
      self.kodi_player= Player()
      try:
         xbmcvfs.mkdir(ADDON_DATA_PATH)
      except:
         i=0
      #self.FFPROBEPATH=utils.extract_ffprobe()
  
      #-------------------
      logMsg('KODI (%s) : Lancement de script.aeon.miro.nox...' %KODI_VERSION)
      #skin.info.service
      if xbmc.getCondVisibility("String.IsEmpty(Window(home).Property(skininfos_daemon_running))"):
        xbmc.executebuiltin('SetProperty(skininfos_daemon_running,True,home)')
      
      
      while not self.kodimonitor.abortRequested():
        if (self.skininfoservice):          
          self.skininfoservice.run_backend()
        
        if xbmcgui.getCurrentWindowDialogId()==12003 and (self.windowhome.getProperty('IconmixShowInfo')!="" or self.closethread):
           #----- Gestion des roles (KODI et TMDB) des acteurs dans la fenetre dialogvideoinfo
           
              MonItem=None 
              logMsg("IconmixShowInfo (%s) / self.closethread (%s)" %(self.windowhome.getProperty('IconmixShowInfo'),self.closethread))        
              if xbmc.getCondVisibility("Control.HasFocus(7779)"):                
                addhistory=True              
                #MonItem=xbmcgui.Window(12003).getControl(5051).getSelectedItem()
                MonItem=self.GetControl(self.windowvideoinf,5051).getSelectedItem()
                TMDBNumber=MonItem.getProperty("TMDBNumber")
                DBTYPE=MonItem.getProperty("dbtype")
                DBID=xbmc.getInfoLabel("Container(5051).ListItem.DBID")
                NomActeur=xbmc.getInfoLabel("Container(1998).ListItem.Label")
                logMsg("ACTEUR ID : (%s) (%s) (%s)" %(xbmc.getInfoLabel("Container(1998).ListItem.DBID"),xbmc.getInfoLabel("Container(1998).CurrentItem"),xbmc.getInfoLabel("Container(1998).NumItems")))
                if not POS5051: #1er appel
                  POS5051=xbmc.getInfoLabel("Container(1998).CurrentItem") 
                utils.logMsg("DBID= %s / DBTYPE = %s / TMDBNUMBER: %s" %(DBID,DBTYPE,TMDBNumber))                
                self.windowhome.clearProperty('DurationAeonEnd')
                self.windowhome.clearProperty('DurationAeon') 
                xbmcgui.WindowDialog(12003).close()
                """               
                if not self.ThreadInfo and len(self.windowinfohistory)<1:
                  #fenetre initiale
                  self.windowinfohistory.append({'keep':1,'dbid':xbmc.getInfoLabel("ListItem.DBID"),'dbtype':xbmc.getInfoLabel("ListItem.DBTYPE"),'tmdbnumber':None})
                else:
                  self.windowinfohistory[-1]['keep']=1
                logMsg("Fermeture %d" %xbmcgui.getCurrentWindowDialogId() )
                xbmc.executebuiltin('Dialog.Close(12003)')
                
                self.windowinfohistory.append({'keep':None,'dbid':DBID,'dbtype':DBTYPE,'tmdbnumber':TMDBNumber,'acteur':NomActeur,'monitem':MonItem,'titre':MonItem.getLabel()})
                self.lastinfo=len(self.windowinfohistory)-1
                """
              """
              elif len(self.windowinfohistory)>0 and self.closethread: 
                logMsg("self.closethread=%s" %self.closethread)               
                addhistory=None
                if self.lastinfo and self.lastinfo>1:
                  self.windowinfohistory.pop()
                data=self.windowinfohistory[-1]
                logMsg("HISTORIQUE : %s" %data)
                DBID=data.get('dbid')
                DBTYPE=data.get('dbtype')
                TMDBNumber=data.get('tmdbnumber')
                Acteur=data.get('acteur')
                KEEP=data.get('keep')
                MonItem=data.get('monitem')
                logMsg("TITRE : %s" %MonItem.getLabel())
                self.windowinfohistory.pop()
                self.closethread=None
              """
              """
                try:
                  self.windowinfohistory[-1]['keep']=None
                except:
                  logMsg("Keep impossible %s" %self.windowinfohistory)
                self.closethread=None
                if DBID:
                  Donnees=utils.ActeurFilmsTvKODI(None,None,1,DBID,DBTYPE)
                  logMsg("DONNEES KODI : %s" %Donnees)
                else:
                  Donnees=utils.ActeurFilmsTvTMDB(None,Acteur,1,TMDBNumber,DBTYPE) 
                  logMsg("DONNEES TMDB : %s" %Donnees)
                if Donnees:
                  MonItem=Donnees[0]
                  logMsg("TITRE : %s" %MonItem.getLabel())
              """
              if MonItem:
                xbmc.executebuiltin('ActivateWindow(busydialognocancel)')              
                logMsg("addhistory=%s" %addhistory)
                if DBID and DBTYPE and DBID!="":  
                  logMsg("KODI")            
                  ListeActeurs=utils.getTMDBMovieDetails(DBID,DBTYPE,1)                
                  if ListeActeurs:
                     utils.logMsg("Casting (%d) = %s" %(len(ListeActeurs),ListeActeurs))
                     MonItem.setCast(ListeActeurs)
                     MonItem.setInfo('video',{'mediatype':DBTYPE,'dbid':int(DBID)})
                     MonItem.setProperty('%sid' %DBTYPE, DBID)
                     MonItem.setProperty('dbtype',DBTYPE)
                     MonItem.setPath(None)  
                     self.previousvideoinfo=DBID
                     TMDBNumber=None            
                elif TMDBNumber and DBTYPE: 
                  logMsg("TMDB")
                  try:
                    fanart=MonItem.getArt().get('fanart') 
                  except:
                    fanart=None
                  duration=MonItem.getVideoInfoTag().getDuration()
                  overview=MonItem.getVideoInfoTag().getPlot()
                  
                  data=utils.getTMDBMovieDetails(TMDBNumber,DBTYPE,None)
                  if data:                  
                    #logMsg("TRAILER : %s" %data.get('trailer'))
                    try:
                      duration = int(data.get("duree"))*60
                    except:
                      duration=None
                    if not overview or overview=="":
                      overview=data.get("overview")
                    if not fanart:
                      logMsg("FANART : %s" %fanart)
                      fanart=data.get('fanart')
                      MonItem.setArt({'fanart':fanart})
                    MonItem.setInfo("video",{'trailer':data.get('trailer'),'duration':duration,'plot':overview})
                    logMsg("Trailer : %s" %data.get('trailer'))
                    MonItem.setProperty("TMDBNumber",TMDBNumber)
                    
                    MonItem.setCast(data.get('Acteurs')) 
                    self.previousvideoinfo=None
                    DBID=None
                  else:
                    logMsg("Aucun acteurs")
                    self.previousvideoinfo=None
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                
                ShowInfoDialog(MonItem,self).start()
                self.closethread=None
                self.previousvideoinfo=None
                while xbmcgui.getCurrentWindowDialogId()!=12003:
                  xbmc.sleep(50)
                logMsg("Actuelle %d" %xbmcgui.getCurrentWindowDialogId() )
                xbmcgui.Window(xbmcgui.getCurrentWindowDialogId()).setFocusId(900171)
                self.windowhome.clearProperty('IconmixShowInfo')
                self.windowhome.setProperty("ActeurVideoLocal","1") 
                logMsg("Quit self.ThreadInfo")   
              
              
        else:
          #logMsg("ICI1 (%s) (%s)" %(xbmcgui.getCurrentWindowDialogId(),xbmcgui.getCurrentWindowId()))
          self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
          
          #----TELEX 15/04/2019
          try:
            self.DBTYPE = xbmc.getInfoLabel("ListItem.DBTYPE").lower()
          except:
            self.DTYPE = ""
          F8889=xbmc.getCondVisibility("Control.HasFocus(8889)")
          F7781=xbmc.getCondVisibility("Control.HasFocus(7781)")
          F7779=xbmc.getCondVisibility("Control.HasFocus(7779)") or xbmc.getCondVisibility("Control.HasFocus(5051)")
          F7777=xbmc.getCondVisibility("Control.HasFocus(7777)") or xbmc.getCondVisibility("Control.HasFocus(7778)")
         
          #-------------------------- ACTEURS : Roles/Bio---------------------------------
              
          if F8889 | F7781 | F7779 |F7777:
            logMsg("CheckActeursRoles")
            self.CompteurTemps=0
            self.CheckActeursRoles(F8889, F7781, F7779,F7777) 
          #----
          
          if (self.selecteditem!=self.previousselecteditem and self.selecteditem!="0"):
            self.previousselecteditem =self.selecteditem
            self.previousvideoinfo=None
            #----TELEX 15/04/2019
            self.windowhome.clearProperty("FileExist")
            #xbmc.executebuiltin("ClearProperty(FileExist,Home)")
            encours=xbmc.getInfoLabel("Player.Filenameandpath")
           
            if self.LectureTheme or "theme.mp3" in encours or "-bo.mp3" in encours:
              self.LectureTheme=None
              #si lecture d'un theme en cours on stoppe si film ou serie selectionnee change
              self.kodi_player.stop()
            if ("tvshow" in self.DBTYPE or "movie" in self.DBTYPE) and (not xbmc.getCondVisibility("Player.HasMedia") or not self.LectureTheme):
              #si le type est tvshow ou movie
              logMsg("Lecture THEME")
              directory=xbmc.getInfoLabel("ListItem.Path")
              if directory:
                utils.logMsg("(REQUETE) de la Liste de fichiers dans %s " %(directory))
                dirs,files=xbmcvfs.listdir(directory)
                song=None
                #utils.logMsg("(RESULTAT) Liste de fichiers dans %s : (%s) " %(directory,str(files[0])))
                
                for filename in files:
                  if "theme.mp3" in filename.lower() or "-bo.mp3" in filename.lower():
                     song= directory+filename
                     break
                if song and xbmcvfs.exists(song): #test si existe
                  #oui, alors on rempli la variable pour le dialogcontext
                  xbmc.executebuiltin("SetProperty(FileExist,OK,Home)")
                  if xbmc.getCondVisibility("Skin.HasSetting(thememusical)"):
                    #lecture auto activee ? oui 
                    try:
                      VolumeTheme=int(xbmc.getInfoLabel("Skin.String(ThemeVolume)"))
                      #recupere le choix de volume de lecture
                    except:
                      VolumeTheme=50 #par defaut
                      
                    self.kodi_player.play(song,windowed=True,VolumeBA=VolumeTheme)
                    #lecture masquee dans la videowindow presente dans myvideonav.xml
                    self.LectureTheme=True
                    #drapeau de lecture en cours 
            #-----------------
            try:
              selectedint=int(self.selecteditem)
            except:
              selectedint=-1
            if (selectedint >-1 and not str(self.selecteditem)==""):
              #if 'movie' in self.DBTYPE or 'episode' in self.DBTYPE:
                #self.windowhome.setProperty('HdrFlagAeon', checkHDR(xbmc.getInfoLabel("ListItem.FileNameAndPath"),xbmc.getInfoLabel("ListItem.VideoResolution"),self.FFPROBEPATH ))
              logMsg("display_duration()")
              self.display_duration()     
            else:
              #self.windowhome.clearProperty('DurationAeonEnd')
              #self.windowhome.clearProperty('DurationAeon')
              self.windowhome.clearProperty('HdrFlagAeon')
          
          if xbmc.getCondVisibility("Window.IsVisible(12003)") :#videoinfo
              
              IconmixShowInfo=self.windowhome.getProperty('IconmixShowInfo')
              self.DBTYPE=xbmc.getInfoLabel("ListItem.DBTYPE")
              NoKodi=None  
              if self.selecteditem=="" or self.selecteditem=="0": 
                    self.selecteditem=xbmc.getInfoLabel("ListItem.Property(TMDBNumber)")
                    self.DBTYPE=xbmc.getInfoLabel("ListItem.Property(DBTYPE)")
                    #logMsg("Selectedvide: (%s) (%s)" %(self.selecteditem,self.DBTYPE))
                    NoKodi=1                    
              
              if self.selecteditem!=self.previousvideoinfo and self.selecteditem!="":
                self.display_duration()
                self.Position1998=0                
                logMsg("videoinfo actif")
                if NoKodi:
                  logMsg("LISTITEM.DBID vide -> %s" %self.selecteditem)
                self.previousvideoinfo=self.selecteditem
                try:
                  self.windowvideoinfo = xbmcgui.Window(12003) # myvideonav.xml 
                  ListeActeurs=self.GetControl(self.windowvideoinfo,1998)
                  #ListeActeursKodi=self.GetControl(self.windowvideoinfo,50)
                except:
                  ListeActeurs=None
                if ListeActeurs:                  
                  if NoKodi:
                    logMsg("cherche acteur TMDB (%s) (%s) (%s)" %(self.DBTYPE,IconmixShowInfo,self.selecteditem))
                    ListeItemx=utils.getCasting(self.DBTYPE,None,1,self.selecteditem) 
                  else:
                    logMsg("cherche acteur KODI (%s) (%s) (%s)" %(self.DBTYPE,IconmixShowInfo,self.selecteditem))
                    ListeItemx=utils.getCasting(self.DBTYPE,self.selecteditem,1,None)
                  logMsg("retour cherche acteur : (%s) (%s)" %(self.selecteditem,len(ListeItemx)))
                  ListeActeurs.reset()
                  
                  if ListeItemx:
                       #ListeActeursKodi.reset()
                       for itemX in ListeItemx:
                            ListeActeurs.addItem(itemX)
                            #ListeActeursKodi.addItem(itemX) 
             
          else:
            self.previousvideoinfo=None
            self.windowhome.clearProperty('IconmixShowInfo') 
            #logMsg("windowinfohistory : %s" %self.windowinfohistory)      
            
        
        xbmc.sleep(400)
            
      logMsg('Arret en cours de script.aeon.miro.nox...', 0)
      
      del self.kodimonitor
      del self.kodi_player
      
      
  def CheckActeursRoles(self,F8889=None, F7781=None, F7779=None,F7777=None,IconmixShowInfo=None,ActeurRealisateur="acteurs"):
      #7779 : roles
      #7781 : acteurs
      #8889 : bio
      #7777 : director (dialogvideoinf)
      #logMsg("CheckActeursRoles (%s) : F8889 (%s) ,  F7781 (%s) ,  F7779 (%s) , F7777 (%s)" %(xbmc.getInfoLabel("Container(1998).ListItem.Label"),F8889 , F7781 , F7779 ,F7777))
      ListeRole=None
      if F8889 | F7781 | F7779 |F7777:
          self.CompteurTemps=0
          if not F8889: #si pas bio
              
              self.selecteditem1998 = xbmc.getInfoLabel("Container(1998).ListItem.Label").split(" (")[0]  
              ActeurRealisateur=xbmc.getInfoLabel("Container(1998).ListItem.Property(DbType)")                 
              
              if self.selecteditem1998:
                self.selecteditem1998=self.selecteditem1998.replace("M. ","")                   
                           
              
              KodiLocal=self.windowhome.getProperty('ActeurVideoLocal')
              if (self.previousitem1998 != self.selecteditem1998 and not str(self.selecteditem1998)=="") or ( self.previousitem1998local!=KodiLocal) or (IconmixShowInfo and self.selecteditem1998) :
                #logMsg("Roles Acteur : %s" %self.selecteditem1998)
                self.Position1998=xbmc.getInfoLabel("Container(1998).Position")
                if not IconmixShowInfo:
                  self.previousitem1998 = self.selecteditem1998
                  self.previousitem1998local=KodiLocal
                  #if xbmc.getCondVisibility("Window.IsVisible(10025)"):
                     #ACTEURS VIDEONAV
                     #ListeRole=self.GetControl(self.windowvideonav,5051)
                     
                  if xbmc.getCondVisibility("Window.IsVisible(12003)"):
                     #ACTEURS VIDEOINFO
                     if not F7777:
                      ListeRole=self.GetControl(self.windowvideoinf,5051)
                     else:
                      ListeRole=self.GetControl(self.windowvideoinf,5052)
                     
                  if xbmc.getCondVisibility("Window.IsVisible(12901)"):
                     #ACTEURS VideoPlayer
                     ListeRole=self.GetControl(self.windowvideoplayer,5051)
                     
                  if xbmc.getCondVisibility("Window.IsVisible(10142)"):
                     #ACTEURS VideoPlayer
                     if not self.windowvideoplayerinfo:
                       self.windowvideoplayerinfo = xbmcgui.Window(10142)                     
                     ListeRole=self.GetControl(self.windowvideoplayerinfo,5051)
                else:
                  try:
                    win=xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
                  except:
                    win=None
                    self.windowhome.clearProperty('IconmixShowInfo')
                  if win:
                    if not F7777:
                      ListeRole=self.GetControl(win,5051)
                    else:
                      ListeRole=self.GetControl(win,5052)                                               
                   
                dialog=None 
                if ListeRole:
                  Acteur=self.selecteditem1998 
                  if not KodiLocal:
                         xbmc.executebuiltin( "ActivateWindow(busydialognocancel)")  
                         ListeItemx=utils.ActeurFilmsTvTMDB(ActeurRealisateur,self.selecteditem1998,1)
                         logMsg("FILMS TMDB (%s) (%s)" %(Acteur,len(ListeItemx)))
                         xbmc.executebuiltin( "Dialog.Close(busydialognocancel)")                         
                  else:
                         logMsg("appel ActeurFilmsTvKODI : %s" %self.selecteditem1998)
                         ListeItemx=utils.ActeurFilmsTvKODI(ActeurRealisateur,self.selecteditem1998,1) #.split(" (")[0],1)
                         logMsg("appel ActeurFilmsTvKODI : %s - retour : %s" %(self.selecteditem1998,len(ListeItemx)))
                         if not ListeItemx:
                            ListeItemx=utils.ActeurFilmsTvTMDB(ActeurRealisateur,self.selecteditem1998,1)
                            self.windowhome.clearProperty("ActeurVideoLocal")
                  ListeRole.reset()
                  if ListeItemx: 
                       for itemX in ListeItemx:
                            ListeRole.addItem(itemX)
                  else:
                     ItemVide = xbmcgui.ListItem(label="******",label2="*******") 
                     ItemVide.setArt({'icon':"defaulttvshows.png"})
                     ItemVide.setProperty("dbtype","movie")
                     ItemVide.setInfo("video", {"title": "????","year": "****","originaltitle": "original_title","trailer":"id"}) 
                     ListeRole.addItem(ItemVide)                                 
                  
                  
          if not F7781:
              ActiF7779="non"
              if F7779  or F7777:
                  if F7779:
                     self.selecteditem8889 = xbmc.getInfoLabel("Container(1998).ListItem.Label")
                  else:
                     if not IconmixShowInfo:
                       self.selecteditem8889 = xbmc.getInfoLabel("ListItem.Director").split(" (")[0]
                     else:
                       self.selecteditem8889 = xbmc.getInfoLabel("Container(1990).ListItem.Director").split(" (")[0] 
              else:
                  if not xbmc.getCondVisibility("Player.HasVideo"):
                      self.selecteditem8889 = xbmc.getInfoLabel("ListItem.DBID")
                  else:
                      self.selecteditem8889 = xbmc.getInfoLabel("VideoPlayer.DBID")                   
                  
              self.previousitem = ""
              self.previousitemMusic = ""
              if (self.previousitem8889 != self.selecteditem8889 and not str(self.selecteditem8889)=="") or IconmixShowInfo:
                  if F7779 or F7777:
                    ActiF7779="oui"
                    if not F7777:
                        self.LABEL8889=xbmc.getInfoLabel("Container(1998).ListItem.Label").split(" (")[0]
                        self.DBTYPE=xbmc.getInfoLabel("Container(1998).ListItem.Property(DbType)")  
                    else:
                        if not IconmixShowInfo:
                           self.LABEL8889 = xbmc.getInfoLabel("ListItem.Director").split(" (")[0]
                        else:
                           self.LABEL8889 = xbmc.getInfoLabel("Container(1990).ListItem.Director").split(" (")[0] 
                        self.DBTYPE="director"
                  else: 
                    self.LABEL8889=xbmc.getInfoLabel("ListItem.Label").split(" (")[0]
                    self.DBTYPE=xbmc.getInfoLabel("ListItem.DBTYPE")
                  if not IconmixShowInfo:  
                    self.previousitem8889 = self.selecteditem8889
                  self.windowhome.clearProperty('Actorbiographie')
                  self.windowhome.clearProperty('Actornaissance')
                  self.windowhome.clearProperty('Actordeces')                                                 
                  self.windowhome.clearProperty('Actorlieunaissance')
                  self.windowhome.clearProperty('ActorAge')
                  self.windowhome.clearProperty('ActorNomReel')
                  InfoDate=None
                  Lieu=None
                  if ActiF7779!="oui": 
                     xbmc.executebuiltin( "ActivateWindow(busydialognocancel)" ) 
                  if not Lieu:                                        
                      #InfoSup=utils.GetActeurInfo(utils.try_decode(self.LABEL8889),self.DBTYPE)
                      InfoSup=utils.GetActeurInfo(self.LABEL8889,self.DBTYPE)
                      #logMsg("Infosup (%s)(%s)(%s)" %(self.LABEL8889,self.DBTYPE,InfoSup))
                      if InfoSup : 
                          self.windowhome.setProperty('Actorbiographie',InfoSup.get("biographie"))
                          Lieu=InfoSup.get("lieunaissance")
                          self.windowhome.setProperty('Actorlieunaissance',InfoSup.get("lieunaissance"))  
                          self.windowhome.setProperty('ActorNomReel',InfoSup.get("nomreel"))

                          InfoDate= InfoSup.get("naissance")

                          if InfoDate:                         
                              XBRegion=str(xbmc.getRegion('dateshort'))
                              if XBRegion=="%d/%m/%Y":                             
                               self.windowhome.setProperty('Actornaissance',str(InfoDate[8:10]+"/"+InfoDate[5:7]+"/"+InfoDate[0:4])) 
                              else:                             
                               self.windowhome.setProperty('Actornaissance',str(InfoDate))                                                             
                              InfoDate= InfoSup.get("deces")                   
                              if InfoDate:
                                  XBRegion=str(xbmc.getRegion('dateshort'))
                                  if XBRegion=="%d/%m/%Y":                             
                                   self.windowhome.setProperty('Actordeces',str(InfoDate[8:10]+"/"+InfoDate[5:7]+"/"+InfoDate[0:4])) 
                                  else:                             
                                   self.windowhome.setProperty('Actordeces',str(InfoDate))
                                  Age=""
                              else:
                                  Age =  str(int(datetime.now().date().year) - int(InfoSup.get("naissance")[0:4])) 
                                  self.windowhome.setProperty('Actorage',Age) 
                  if ActiF7779!="oui": 
                      xbmc.executebuiltin( "Dialog.Close(busydialognocancel)" )
                  
                  if not InfoDate and not Lieu:
                           if ActiF7779!="oui": 
                               dialog=xbmcgui.Dialog()
                               dialog.notification('IconMixTools', __language__( 32584 )+self.LABEL8889, "acteurs/arfffff.png", 3000)
                               if not IconmixShowInfo:
                                  xbmc.executebuiltin("SetFocus(55)")          
              
  def GetControl(self,Window=None,Id=None):
      ControlId=None
      
      if Window:
                    
          try:
               ControlId=Window.getControl(Id)  
          except:
               ControlId=None
      return ControlId
          
  def display_duration(self):
        
        xxx="null"
        self.duration = None
        if xbmc.getInfoLabel("ListItem.DbType")!="set":
          self.duration = xbmc.getInfoLabel("ListItem.Duration") 
        else:
          totalruntime=utils.getMovieSetTotaltime(self.selecteditem)
          #logMsg("Runtime SAGA retour = %s" %totalruntime)
          if totalruntime>0:
            self.duration=str(totalruntime)
         
        
        
        self.windowhome.clearProperty('DurationAeonEnd')
        self.windowhome.clearProperty('DurationAeon')
        if self.duration :
           self.duration=self.duration.split('.')[0]
           if self.duration.find(':')!=-1: #KODI LEIA
              TT=self.duration.rsplit(':')
              XX=0
              if len(TT)==3:
                XX=XX+int(TT[0])*60
                XX=XX+int(TT[1])
              if len(TT)==2:
                XX=int(TT[0])
              if len(TT)>1:
               self.duration=str(XX)
          
           if self.duration.find(':')==-1:
              readable_duration = in_hours_and_min(self.duration)
              logMsg("duration = (%s) (%s)" %(self.duration,readable_duration))
              
              if readable_duration:
                self.windowhome.setProperty('DurationAeon', readable_duration)
                now = datetime.now()
                now_plus_10 = now + timedelta(minutes = int(self.duration))
                xxx = format(now_plus_10, '%Hh%M')
                self.windowhome.setProperty('DurationAeonEnd', xxx)
                #logMsg('Duree = (%s) / Fin = (%s)' %(readable_duration,xxx))
              else:
                self.windowhome.clearProperty('DurationAeonEnd')
                self.windowhome.clearProperty('DurationAeon')
           else:
             self.windowhome.setProperty('DurationAeon', self.duration)
             #logMsg('Duree Kodi = (%s) ' %(self.duration))
        else:
                self.windowhome.clearProperty('DurationAeonEnd')
                self.windowhome.clearProperty('DurationAeon') 
      
MainService()