# coding: utf-8
#from __future__ import unicode_literals
import resources.lib.Utils as utils
from resources.lib.Utils import logMsg
from datetime import datetime,timedelta
import _strptime
try:
  from urllib import parse
except:
  import urlparse as parse
import time
from time import sleep
import unicodedata
import os
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,xbmcvfs
import random
try:
  from xbmcvfs import translatePath as translatePath
except:
  from xbmc import translatePath as translatePath

# Script constantes
ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_DATA_PATH = translatePath("special://profile/addon_data/%s" % ADDON_ID)
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])



  

class Main:
    def __init__( self ):
        
        #get params
        action = None
        try:
         params = parse.parse_qs(sys.argv[2][1:])
        
         if params:        
            path=params.get("path",None)
            if path: path = path[0]
            limit=params.get("limit",None)
            if limit: limit = int(limit[0])
            else: limit = 25
            action=params.get("action",None)
            if action: action = action[0].upper()
        
         if action:                         
 
             if action == "GETCAST": # l'appel arrive ici via <content>plugin://script.aeonmironox/?action=getcast&infotype=movie&id=VideoPlayer.DBID</content> par exemple
                Id=params.get("id",None) #on récupere le dbid transmis
                if Id: Id = Id[0] 
                castingtype=params.get("casttype",None) #on recupere le type : movie ou tvshow
                if castingtype: castingtype = castingtype[0]
                utils.logMsg("DebugPlugin :ItemId="+str(Id)+" - Type "+str(castingtype),0)
                utils.getCasting(castingtype,Id) #on appelle la fonction dans utils.py
                
             if action == "GETTVFILMS": # l'appel arrive ici via  <content>plugin://script.aeonmironox/?action=gettvfilms&nom=$INFO[Container(19998).ListItem.Label]&type=actor</content>
                Nom=params.get("nom",None) #on récupere le dbNom transmis
                
                if Nom: Nom = Nom[0]                 
                actordirectortype=params.get("videotype",None) #on recupere le type : movie ou tvshow
                
                if actordirectortype: actordirectortype = actordirectortype[0]
                  
                utils.logMsg("ActeurFilmsTvKODI : (%s) (%s)" %(Nom,actordirectortype),0)
                utils.ActeurFilmsTvKODI(actordirectortype,Nom) #on appelle la fonction dans utils.py
             
        except:
           params= {}  
        try:
            params = dict( arg.split( '=' ) for arg in sys.argv[ 1 ].split( '&' ) )
        except:
            params = {}
        
        

 
          
if (__name__ == "__main__"):
    Main()
    