# AeonMiroNoxTOOLS


Fonctions suppl�mentaires pour mon Skin AeonMiroNox
(Tools for my skin AeonMiroNox )

NAS source detection updated in 1.0.23: relies on ListItem.Path and normalized SerieSource1/SerieSource2 settings.
