#!/usr/bin/python
# coding: utf-8
#from __future__ import unicode_literals
import xbmcplugin, xbmcgui, xbmc, xbmcaddon, xbmcvfs
import os,sys,io,shutil
import urllib2, urllib
import httplib
import datetime

import _strptime
import time
import unicodedata
import urlparse
from xml.dom.minidom import parse
import json
import sqlite3
import operator
import locale
import hashlib
import base64
import xml.etree.ElementTree as ET
    
try:
    to_unicode = unicode
except NameError:
    to_unicode = str
    

ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id').decode("utf8")
ADDON_ICON = ADDON.getAddonInfo('icon').decode("utf8")
ADDON_NAME = ADDON.getAddonInfo('name').decode("utf8")
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf8")
ADDON_VERSION = ADDON.getAddonInfo('version').decode("utf8")
ADDON_DATA_PATH = xbmc.translatePath("special://profile/addon_data/%s" % ADDON_ID).decode("utf8")
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])
WINDOW = xbmcgui.Window(10000)
SETTING = ADDON.getSetting
KODILANGUAGE = xbmc.getInfoLabel( "System.Language" )
sys.path.append(xbmc.translatePath(os.path.join(ADDON_PATH, 'resources', 'lib')).decode('utf8'))


def logMsg(msg, level = 0): #ca c'est pour debugger. ca ecrit le message MSG dans Kodi.log
    if WINDOW.getProperty("IconMixTools.enableDebugLog") == "true" or level == 0:
        if isinstance(msg, unicode):
            msg = msg.encode('utf8')
        if "exception" in msg.lower() or "error" in msg.lower():
            xbmc.log("IconMixTools addon --> " + msg, level=xbmc.LOGERROR)
            #print_exc()
        else:
            xbmc.log("IconMixTools addon --> " + msg, level=xbmc.LOGNOTICE)




# --------------------------------------------UTILITAIRES/PLUGIN----------------------------------------------
def Remove_Separator(Chaine=None):
  if Chaine:
    Chaine=Chaine.split("/")[0].rstrip()
    Chaine=Chaine.split("&")[0].rstrip()
    Chaine=Chaine.split(",")[0].rstrip()
    Chaine=Chaine.replace('"','')
    Chaine=Chaine.replace("'",'')
  return Chaine  

def GetListItemInfoLabelsJson(data=None):
    
  if data:
    Valeur={}
    
    Valeur["genre"]=data.get("genre")
    if data.get("country"):
      Country=[]
      if len(data.get("country"))>1:
        for xx in data.get("country"):
          Country.append(xx)
      else:
        Country=data.get("country")[0]
     
      Valeur["country"]=Country
    Valeur["year"]=int(data.get("year")) if data.get("year") else None
    if not Valeur["year"]:
        if data.get("firstaired"):
            try:
             Valeur["year"]=int(data.get("firstaired").split("-")[0])
            except:
             Valeur["year"]=None   
        else:
           if data.get("premiered"):
            try:
              Valeur["year"]=int(data.get("premiered").split("-")[0])
            except:
              Valeur["year"]=None
              
    Valeur["top250"]=int(data.get("top250")) if data.get("top250") else None
    Valeur["setid"]=int(data.get("setid")) if data.get("setid") else None
    Valeur["rating"]=float(data.get("rating")) if data.get("rating") else None
    Valeur["userrating"]=int(data.get("userrating")) if data.get("userrating") else None
    Valeur["playcount"]=int(data.get("playcount")) if data.get("playcount") else None
    Valeur["overlay"]=int(data.get("overlay")) if data.get("overlay") else None
 
    if data.get("cast"):
      Casting=[]
      CastingRole=[]
      for xx in data.get("cast"):
        Casting.append(xx["name"])
        CastingRole.append((xx["name"],xx["role"]))      
      Valeur["castandrole"]=CastingRole
      Valeur["cast"]=Casting
    if data.get("director"):
      director=[]
      if len(data.get("director"))>1:
        for xx in data.get("director"):
          director.append(xx)
      else:
        director=data.get("director")[0]
      Valeur["director"]=director
    
    
    Valeur["mpaa"]=data.get("mpaa")
    Valeur["plot"]=data.get("plot")
    Valeur["plotoutline"]=data.get("plotoutline")
    Valeur["title"]=data.get("title")
    Valeur["originaltitle"]=data.get("originaltitle")
    Valeur["duration"]=int(data.get("duration")) if data.get("duration") else None
    if data.get("studio"):
      studio=[]
      if len(data.get("studio"))>1:
        for xx in data.get("studio"):
          studio.append(xx)
      else:
        studio=data.get("studio")[0]
      Valeur["studio"]=studio
    Valeur["tagline"]=data.get("tagline")
    if data.get("writer"):
      writer=[]
      if len(data.get("writer"))>1:
        for xx in data.get("writer"):
          writer.append(xx)
      else:
        writer=data.get("writer")[0]
      Valeur["writer"]=writer
    Valeur["tvshowtitle"]=data.get("showtitle")
    Valeur["premiered"]=data.get("premiered")
    Valeur["status"]=data.get("status")
    Valeur["set"]=data.get("set")
    Valeur["firstaired"]=data.get("firstaired")
    Valeur["imdbnumber"]=data.get("imdbnumber")
    if data.get("credits"):
      credits=[]
      if len(data.get("credits"))>1:
        for xx in data.get("credits"):
          credits.append(xx)
      else:
        credits=data.get("credits")[0]
      Valeur["credits"]=credits
    Valeur["lastplayed"]=data.get("lastplayed")
    Valeur["votes"]=data.get("votes")
    Valeur["path"]=data.get("file")
    Valeur["trailer"]=data.get("trailer")
    Valeur["dateadded"]=data.get("dateadded")
    
    Valeur["dbid"]=None
    if data.get("movieid"):
      Valeur["dbid"]=int(data.get("movieid"))
      Valeur["mediatype"]="movie"
    if data.get("tvshowid"):
      Valeur["dbid"]=int(data.get("tvshowid"))
    if data.get("episodeid"):
      Valeur["dbid"]=int(data.get("episodeid"))
      Valeur["mediatype"]="tvshow"
      Valeur["episode"]=data.get("episode") if data.get("episode") else None
      Valeur["season"]=data.get("season") if data.get("season") else None
      
    #logMsg("Valeur : (%s)" %(Valeur["dbid"]))
    return Valeur
  else:
    return None   

def ActeurFilmsTvKODI(ActeurType=None,Acteur=None):
  Donnees = []
  item = {}
  Casting = []
  RechercheType=""
  VideoPoster="" 
  ListeVideos=[]
  
  #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"filter":{"actor":"marion cotillard"},"properties":["thumbnail","year","file"]},"id":"1"}
  #videodb://movies/actors/1132/   1132=id acteur pour retrouver ses films
  if  (len(sys.argv)>1 and sys.argv[1]) :
      if Acteur:
         if ActeurType and ActeurType=="director":
            Ok=""
         else: ActeurType="actor"
         IdPlayer=xbmc.getInfoLabel("VideoPlayer.DbId")
          
         Acteur=Remove_Separator(Acteur)
         json_result = getJSON("VideoLibrary.GetMovies", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["title","genre","year","rating","userrating","director","trailer","tagline","plot","plotoutline","originaltitle","lastplayed","playcount","writer","studio","mpaa","cast","country","imdbnumber","runtime","set","showlink","streamdetails","top250","votes","fanart","thumbnail","file","sorttitle","resume","setid","dateadded","tag","art"]}' %(ActeurType,Acteur))
         json_result2 = getJSON("VideoLibrary.GetTvShows", '{"filter":{"field":"%s","operator":"contains","value":"%s"},"properties":["plot","thumbnail","year","file","art","imdbnumber","rating","userrating","cast"]}' %(ActeurType,Acteur))
         #http://127.0.0.1:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":30,"properties":["cast"],"filter":{"actor":"CynthiaAddai-Robinson"}},"id":"1"}
         #pour obtenir tous les episodes comprenant l'acteur
         
         if len(json_result)>0:
          Donnees=json_result
         if len(json_result2)>0:
          Donnees=Donnees+json_result2        
         #movie, tvshow
         if Donnees:
           ListeVideos=[]
           for Item in Donnees:
             Titre=Item.get("label")
             if Titre:
                 IdVideo=Item.get("movieid")
                 TypeVideo="movie"
                 if not IdVideo: 
                    IdVideo=Item.get("tvshowid")
                    TypeVideo="tvshow"
                 #logMsg("IdPlayer (%s) / IdVideo (%s)" %(IdPlayer,IdVideo))
                 ItemListe = xbmcgui.ListItem(label=Titre,iconImage=Item.get("art").get("poster"))
                 ItemListe.setProperty("poster",Item.get("art").get("poster")) 
                 Casting = Item.get("cast")
                 if Casting:
                    for ItemCast in  Casting:
                         if ItemCast.get("name").encode('utf8')==Acteur:
                              ItemListe.setLabel2(ItemCast.get("role"))
                              break  
                 
                 
                 ItemListe.setArt( Item.get("art"))
                 Fanart=Item.get("art").get("fanart")
                 if Fanart:
                     ItemListe.setProperty("fanart",Fanart)
                 else:
                     ItemListe.setProperty("fanart","")
                 
                 ItemListe.setProperty('DBID', str(IdVideo))
                 ItemListe.setProperty('dbtype',TypeVideo)
                 ItemListe.setProperty('IMDBNumber', str(Item.get("imdbnumber")))
                 ItemListe.setProperty('Rating',str(int(Item.get("rating")))) 
                 UserRating=Item.get("userrating")
                 if UserRating:
                     if int(UserRating)>0:
                       ItemListe.setProperty('UserRating',str(int(Item.get("userrating"))))
                     else:
                       ItemListe.setProperty('UserRating','')
                 
                 #pistes audios tele
                 try:
                   Audio=Item.get("streamdetails").get("audio")
                 except:
                   Audio=None
                 i=1
                 if Audio:               
                       for AudioElement in Audio:
                            ItemListe.setProperty('AudioLanguage.%d' %(i), AudioElement.get("language"))
                            ItemListe.setProperty('AudioChannels.%d' %(i), str(AudioElement.get("channels")))
                            ItemListe.setProperty('AudioCodec.%d' %(i), AudioElement.get("codec")) 
                            ItemListe.addStreamInfo('audio',AudioElement)                   
                            i=i+1
            
                  #pistes vid�os 
                 try:
                   Video=Item.get("streamdetails").get("video")
                 except:
                   Video=None
                 i=0
                 Codec=""
                 if Video:
                    #{"aspect":2.3975000381469726563,"codec":"h264","duration":5584,"height":800,"language":"eng","stereomode":"","width":1918}
                    for VideoItem in Video:
                       ItemListe.setProperty('VideoCodec', VideoItem.get("codec")) 
                       ItemListe.addStreamInfo('video',VideoItem)
                       
                  #sous-titres  
                 try:   
                   Subtitles=Item.get("streamdetails").get("subtitle")
                 except:
                   Subtitles=None
                 i=1
                  
                 if Subtitles:
                       for SubtitleElement in Subtitles:
                            ItemListe.setProperty('SubtitleLanguage.%d' %(i), SubtitleElement.get("language"))  
                            ItemListe.addStreamInfo('subtitle',SubtitleElement)                   
                            i=i+1
                 InfoLabels=GetListItemInfoLabelsJson(Item)
                 if InfoLabels:
                   InfoLabels["mediatype"]= TypeVideo
                   #ItemListe.setInfo("video", {"dbid": str(IdVideo),"mediatype": TypeVideo,"title": Titre,"year": Item.get("year"),"trailer":Item.get("trailer"),"plot":Item.get("plot")})
                   if str(IdPlayer)==str(IdVideo):
                      InfoLabels["dbid"]=None
                   
                   ItemListe.setInfo("video", InfoLabels)
                   if str(IdPlayer)==str(IdVideo):
                      ListeVideos.append(["",ItemListe,False])
                   else:
                      
                      ListeVideos.append([Item.get("file"),ItemListe,False])
                   
  xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeVideos)       
  xbmcplugin.endOfDirectory(int(sys.argv[1])) 
# ----------------------------------------------------------------  
        
def getCasting(Castingtypex=None,ItemId=None):
  #Castingtypex : type de la base � la rechercher : soit "movie" soit "tvshow"
  #ItemId : ID du film (ListItem.DBID ou VideoPlayer.DBID) � rechercher
  allCast = []
  item = {}
  Casting = []
  Castingtype=""
  imageacteur="" 
  ListeActeur=[]
  
  
  
  
  logMsg("Debug :ItemId="+str(ItemId)+" - Type "+str(Castingtypex),0) 
  if sys.argv[1]: # ca c'est ce qu'on appelle un pointeur vers le container de Kodi � remplir
      
      if Castingtypex and ItemId:   
         #if Castingtypex=="episode":            Castingtypex="tvshow"
    
         Castingtype="VideoLibrary.Get%sDetails" %(Castingtypex)
         # en r�sum� ici on pr�pare l'appel aux fonctions JSON
         # si c'est un film ce sera VideoLibrary.GetMovieDetails ( http://kodi.wiki/view/JSON-RPC_API/v6#VideoLibrary.GetMovieDetails )
         # si c'est une s�rie ce sera VideoLibrary.GetTvShowDetails (http://kodi.wiki/view/JSON-RPC_API/v6#VideoLibrary.GetTVShowDetails )
         json_result = getJSON(Castingtype, '{ "%sid":%d,"properties": [ "cast"]}' %(Castingtypex,int(ItemId)))
         logMsg("Castingtype (%s) (%s)" %(Castingtype,json_result))
         #appel de la fonction avec la liste du casting en retour ["cast"]
         #exemple de retour dans la variable json_result pour l'appel suivant :
         #http://192.168.1.13:8080/jsonrpc?request={"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":21,"properties":["cast"]},"id":1}
         #
         #{"id":1,"jsonrpc":"2.0",
         #"result":{"moviedetails":
         # {"cast":[
         #   {"name":"Melanie Stone","order":1,"role":"Marek","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2f4mIlmaMmuRlwlrdbbmAKEidArhJ.jpg/"},
         #   {"name":"Kevin Sorbo","order":2,"role":"Gojun Pye","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2fa6rDi3tkNJwaVoP7VGbdGelwtYw.jpg/"},
         #   {"name":"Adam Johnson","order":3,"role":"Thane","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2fjr3cne62q08VNZu7OhSTd4FdirF.jpg/"},
         #   {"name":"Jake Stormoen","order":4,"role":"Dagen","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2f7ztQwCxm0GrzdZOqyeCUN9nYGAV.jpg/"},
         #   {"name":"Rocky Myers","order":5,"role":"Qole","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2fzJSQB7IAbO1o3q105XX6hFFMlv4.jpg/"},
         #   {"name":"Matthew Mercer","order":6,"role":"Szorlok","thumbnail":"image://http%3a%2f%2fimage.tmdb.org%2ft%2fp%2foriginal%2ffe1S317253vfMuNuIDjhp9vtNSs.jpg/"},
         #   {"name":"Kynan Griffin","order":7,"role":"Gefrorener Zauberer"}
         #     ],"label":"Mythica : La Pierre de Pouvoir","movieid":21}}}
         
         if json_result:
            allCast = json_result.get("cast")  #on r�cup�re toutes les donn�es du tableau "cast" dans allCast
                                               #tu auras dans chaque ligne du tableau les champs "name","order","role" et "thumbnail"
         if allCast:
           for Test in allCast: # l� on va extraire chaque ligne du tableau
             name=Test.get("name") # on recup�re le nom de l'acteur
             
             if name:
                 imageacteur=Test.get("thumbnail") #on recup�re l'adresse de l'image de l'acteur
                 if not imageacteur :
                    imageacteur="DefaultActor.png" #ici si aucune image, on met une image par d�faut ...celle l� est dans mon skin
                 #else :
                 if imageacteur: # si tout s'est bien pass�
                     ItemListe = xbmcgui.ListItem(label=name,iconImage=imageacteur,label2=Test.get("role"))  
                     #on cr�� un �l�ment de type ListItem qu'on remplit                    
                     ListeActeur.append(["",ItemListe,True])
                     #on ajoute l'�l�ment rempli dans une liste
                    
  
  xbmcplugin.addDirectoryItems(int(sys.argv[1]), ListeActeur)
  #on �crit la liste ListeActeur dans le container de Kodi
  xbmcplugin.endOfDirectory(int(sys.argv[1]))
  #on indique � Kodi que le container est pr�t
  
 

def getMovieSetTotaltime(SetID=None):
  TotalRuntime=0
  if SetID:
    
    json_result = getJSON('VideoLibrary.GetMovieSetDetails', '{ "setid":%d,"movies":{"properties": ["runtime"]} }' %(int(SetID)))
    if json_result and json_result.get("movies"): 
           allMovies = json_result.get("movies")
           for item in allMovies:
             Runtime=item.get("runtime")
             logMsg("Runtime (%s)" %(Runtime),0)
             try:
              IRunTime=int(Runtime)
             except:
              IRunTime=0
             TotalRuntime=TotalRuntime+IRunTime
           if TotalRuntime>0:
            TotalRuntime=TotalRuntime/60    
  return TotalRuntime

def GetVolume():
  json_result = getJSON('Application.GetProperties','{"properties":["volume","muted"]}')
  if json_result:
     return json_result.get("volume")

# --------------------------------------------------------------------------------------------------
    
def getJSON(method,params):
    json_response = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method" : "%s", "params": %s, "id":1 }' %(method, try_encode(params)))
    jsonobject = json.loads(json_response.decode('utf8','replace'))
    if(jsonobject.has_key('result')):
        jsonobject = jsonobject['result']
        if isinstance(jsonobject, list):
            return jsonobject
        if jsonobject.has_key('files'):
            return jsonobject['files']
        elif jsonobject.has_key('movies'):
            return jsonobject['movies']
        elif jsonobject.has_key('tvshows'):
            return jsonobject['tvshows']
        elif jsonobject.has_key('seasons'):
            return jsonobject['seasons']
        elif jsonobject.has_key('episodes'):
            return jsonobject['episodes']
        elif jsonobject.has_key('musicvideos'):
            return jsonobject['musicvideos']
        elif jsonobject.has_key('channels'):
            return jsonobject['channels']
        elif jsonobject.has_key('recordings'):
            return jsonobject['recordings']
        elif jsonobject.has_key('timers'):
            return jsonobject['timers']
        elif jsonobject.has_key('channeldetails'):
            return jsonobject['channeldetails']
        elif jsonobject.has_key('recordingdetails'):
            return jsonobject['recordingdetails']
        elif jsonobject.has_key('songs'):
            return jsonobject['songs']
        elif jsonobject.has_key('albums'):
            return jsonobject['albums']
        elif jsonobject.has_key('songdetails'):
            return jsonobject['songdetails']
        elif jsonobject.has_key('albumdetails'):
            return jsonobject['albumdetails']
        elif jsonobject.has_key('artistdetails'):
            return jsonobject['artistdetails']
        elif jsonobject.get('favourites'):
            return jsonobject['favourites']
        elif jsonobject.has_key('tvshowdetails'):
            return jsonobject['tvshowdetails']
        elif jsonobject.has_key('episodedetails'):
            return jsonobject['episodedetails']
        elif jsonobject.has_key('moviedetails'):
            return jsonobject['moviedetails']
        elif jsonobject.has_key('setdetails'):
            return jsonobject['setdetails']
        elif jsonobject.has_key('musicvideodetails'):
            return jsonobject['musicvideodetails']
        elif jsonobject.has_key('sets'):
            return jsonobject['sets']
        elif jsonobject.has_key('video'):
            return jsonobject['video']
        elif jsonobject.has_key('artists'):
            return jsonobject['artists']
        elif jsonobject.has_key('channelgroups'):
            return jsonobject['channelgroups']
        elif jsonobject.get('sources'):
            return jsonobject['sources']
        elif jsonobject.has_key('addons'):
            return jsonobject['addons']
        elif jsonobject.has_key('item'):
            return jsonobject['item']
        elif jsonobject.has_key('genres'):
            return jsonobject['genres']
        elif jsonobject.has_key('value'):
            return jsonobject['value']
        else:
            return jsonobject

    else:
        return {}
        



def try_encode(text, encoding="utf8"):
    try:
        return text.encode(encoding,"ignore")
    except:
        return text

def try_decode(text, encoding="utf8"):
    try:
        return text.decode(encoding,"ignore")
    except:
        return text
