﻿# coding: utf-8
#from __future__ import unicode_literals
import resources.lib.Utils as utils
from resources.lib.Utils import logMsg
from datetime import datetime,timedelta
import _strptime
import urlparse
import time
from time import sleep
import unicodedata
import os
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,xbmcvfs
import random

# Script constantes
ADDON = xbmcaddon.Addon()
__addonid__    = ADDON.getAddonInfo('id')
__version__    = ADDON.getAddonInfo('version')
__language__   = ADDON.getLocalizedString
__cwd__        = ADDON.getAddonInfo('path')  
ADDON_ID = ADDON.getAddonInfo('id').decode("utf8")
ADDON_ICON = ADDON.getAddonInfo('icon').decode("utf8")
ADDON_NAME = ADDON.getAddonInfo('name').decode("utf8")
ADDON_PATH = ADDON.getAddonInfo('path').decode("utf8")
ADDON_VERSION = ADDON.getAddonInfo('version').decode("utf8")
ADDON_DATA_PATH = xbmc.translatePath("special://profile/addon_data/%s" % ADDON_ID).decode("utf8")
KODI_VERSION  = int(xbmc.getInfoLabel( "System.BuildVersion" ).split(".")[0])




def in_hours_and_min(minutes_string):
    try:
        full_minutes = int(minutes_string)
        minutes = full_minutes % 60
        hours   = full_minutes // 60
        return str(hours) + 'h' + str(minutes).zfill(2)
    except:
        return None
#---- TELEX 15/04/2019 ----
class Player(xbmc.Player):

  #------------------------------------------------------------------------------------------------------------------
  def play(self, item='', listitem=None, windowed=False, sublist=None,VolumeBA=None):
      self.Volume=VolumeBA #volume de lecture du theme/bande annonce
      self.VolumeOrg=utils.GetVolume() #sauvegarde du volume actuel
      #xbmc.executebuiltin("SetVolume(%d,true)" %self.Volume)
      utils.logMsg("Lancement de la lecture : %s (%s)(%s)" %(str(item),self.VolumeOrg,self.Volume))
      super(Player, self).play(item, listitem, windowed)  
   

  #------------------------------------------------------------------------------------------------------------------
  def __init__(self):
      self.windowhome = xbmcgui.Window(10000)
      self.windowvideo = xbmcgui.Window(10025)
      self.Volume=None      
      xbmc.Player.__init__(self,0)

  #------------------------------------------------------------------------------------------------------------------
  def onPlayBackStarted(self):        
      if self.Volume:
           utils.logMsg("reglage du volume de lecture")
           xbmc.executebuiltin("SetVolume(%d,true)" %self.Volume) 
     

  #------------------------------------------------------------------------------------------------------------------
  def onPlayBackStopped(self):
      utils.logMsg("arret de la lecture")
      if self.Volume and self.VolumeOrg:
           utils.logMsg("retablissement du volume apres lecture (%s)" %self.VolumeOrg)
           xbmc.executebuiltin("SetVolume(%d,true)" %self.VolumeOrg) #retablissement volume original
      
      
      

  

class MainService:
  
    #------------------------------------------------------------------------------------------------------------------
  def __init__(self):         
      
      self.kodimonitor = xbmc.Monitor()
      self.windowhome = xbmcgui.Window(10000) # Home.xml 
      self.previousselecteditem=None
      self.duration = None
      #----TELEX 15/04/2019
      self.LectureTheme=None
      self.kodi_player= Player()
      #-------------------
      logMsg('Lancement de script.aeon.miro.nox...', 0)
      while not self.kodimonitor.abortRequested():
        self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
        
        #----TELEX 15/04/2019
        self.DBTYPE = xbmc.getInfoLabel("ListItem.DBTYPE")
        #----
        
        if (self.selecteditem!=self.previousselecteditem):
          self.previousselecteditem =self.selecteditem
          #----TELEX 15/04/2019
          xbmc.executebuiltin("ClearProperty(FileExist,Home)")
          encours=xbmc.getInfoLabel("Player.Filenameandpath")
         
          if self.LectureTheme or "theme.mp3" in encours or "-bo.mp3" in encours:
            self.LectureTheme=None
            #si lecture d'un theme en cours on stoppe si film ou serie selectionnee change
            self.kodi_player.stop()
          if ("tvshow" in self.DBTYPE or "movie" in self.DBTYPE)and (not xbmc.getCondVisibility("Player.HasMedia") or not self.LectureTheme):
            #si le type est tvshow ou movie
            
            directory=xbmc.getInfoLabel("ListItem.Path")
            utils.logMsg("(REQUETE) de la Liste de fichiers dans %s " %(directory))
            dirs,files=xbmcvfs.listdir(directory)
            song=None
            utils.logMsg("(RESULTAT) Liste de fichiers dans %s : (%s) " %(directory,files))
            for filename in files:
              if "theme.mp3" in filename.lower() or "-bo.mp3" in filename.lower():
                 song= directory+filename
                 break
            if song and xbmcvfs.exists(song): #test si existe
              #oui, alors on rempli la variable pour le dialogcontext
              xbmc.executebuiltin("SetProperty(FileExist,OK,Home)")
              if xbmc.getCondVisibility("Skin.HasSetting(thememusical)"):
                #lecture auto activee ? oui 
                try:
                  VolumeTheme=int(xbmc.getInfoLabel("Skin.String(ThemeVolume)"))
                  #recupere le choix de volume de lecture
                except:
                  VolumeTheme=50 #par defaut
                  
                self.kodi_player.play(song,windowed=True,VolumeBA=VolumeTheme)
                #lecture masquee dans la videowindow presente dans myvideonav.xml
                self.LectureTheme=True
                #drapeau de lecture en cours 
          #-----------------
          if (self.selecteditem>-1 and not str(self.selecteditem)==""):
            
            self.display_duration()     
          else:
            self.windowhome.clearProperty('DurationAeonEnd')
            self.windowhome.clearProperty('DurationAeon')     
        xbmc.sleep(400)
            
      logMsg('Arret en cours de script.aeon.miro.nox...', 0)
      
      del self.kodimonitor
      del self.kodi_player
      
      
      
      
  def display_duration(self):
       
        xxx="null"
        self.duration = None
        if xbmc.getInfoLabel("ListItem.DbType")!="set":
          self.duration = xbmc.getInfoLabel("ListItem.Duration") 
        else:
          totalruntime=utils.getMovieSetTotaltime(self.selecteditem)
          if totalruntime>0:
            self.duration=str(totalruntime)
         
        
        
        self.windowhome.clearProperty('DurationAeonEnd')
        self.windowhome.clearProperty('DurationAeon')
        if self.duration :
           if self.duration.find(':')!=-1: #KODI LEIA
              TT=self.duration.rsplit(':')
              XX=0
              if len(TT)==3:
                XX=XX+int(TT[0])*60
                XX=XX+int(TT[1])
              if len(TT)==2:
                XX=int(TT[0])
              if len(TT)>1:
               self.duration=str(XX)
          
           if self.duration.find(':')==-1:
              readable_duration = in_hours_and_min(self.duration)
              logMsg('readable_duration = (%s)' %(readable_duration))
              self.windowhome.setProperty('DurationAeon', readable_duration)
              if readable_duration:
                now = datetime.now()
                now_plus_10 = now + timedelta(minutes = int(self.duration))
                xxx = format(now_plus_10, '%Hh%M')
                self.windowhome.setProperty('DurationAeonEnd', xxx)
              else:
                self.windowhome.clearProperty('DurationAeonEnd')
                self.windowhome.clearProperty('DurationAeon')
           else:
             self.windowhome.setProperty('DurationAeon', self.duration)
        else:
                self.windowhome.clearProperty('DurationAeonEnd')
                self.windowhome.clearProperty('DurationAeon') 
      
MainService()